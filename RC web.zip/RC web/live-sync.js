// live-sync.js - Universal Real-Time Supabase & CMS Synchronization Engine for RC Sindhri
// Seamlessly connects all frontend pages to live database changes from the Admin Panel.

(function () {
  'use strict';

  const LiveSync = {
    contentMap: {},
    settingsMap: {},
    statsMap: {},

    async init() {
      try {
        await this.fetchData();
        this.applyBranding();
        this.applyAnnouncement();
        this.applyHeroContent();
        this.applyPageCovers();
        this.applyStatistics();
        this.applyContactInfo();
        this.applyAboutContent();
        this.applyFooterSocial();
      } catch (err) {
        // Fail silently and preserve original static HTML
        console.debug('LiveSync offline or fallback active:', err.message);
      }
    },

    async fetchData() {
      const base = (window.location.protocol === 'file:') ? 'http://localhost:3000' : '';
      const [contentRes, statsRes, settingsRes] = await Promise.all([
        fetch(base + '/api/content').then(r => r.ok ? r.json() : null).catch(() => null),
        fetch(base + '/api/statistics').then(r => r.ok ? r.json() : null).catch(() => null),
        fetch(base + '/api/settings').then(r => r.ok ? r.json() : null).catch(() => null)
      ]);

      if (contentRes && contentRes.content) {
        contentRes.content.forEach(item => {
          this.contentMap[item.section_key] = item;
        });
        if (contentRes.settings) {
          contentRes.settings.forEach(s => {
            this.settingsMap[s.setting_key] = s.setting_value;
          });
        }
      }

      if (settingsRes && settingsRes.settings) {
        this.settingsMap = { ...this.settingsMap, ...settingsRes.settings };
      }

      if (statsRes && statsRes.statistics) {
        this.statsMap = statsRes.statistics;
      }
    },

    // 1. Website Logo & Branding Sync
    applyBranding() {
      const customLogo = this.settingsMap['website_logo_url'] || this.contentMap['site_branding']?.metadata?.logo_url;
      const brandTitle = this.settingsMap['website_title'] || this.contentMap['site_branding']?.title;
      const brandSubtitle = this.settingsMap['website_subtitle'] || this.contentMap['site_branding']?.subtitle;

      if (customLogo) {
        document.querySelectorAll('.nav-logo').forEach(logoLink => {
          let customImg = logoLink.querySelector('.nav-custom-logo-img');
          const existingSvg = logoLink.querySelector('.nav-logo-svg');
          if (!customImg) {
            customImg = document.createElement('img');
            customImg.className = 'nav-custom-logo-img';
            customImg.style.maxHeight = '52px';
            customImg.style.width = 'auto';
            customImg.style.display = 'block';
            customImg.style.objectFit = 'contain';
            customImg.alt = brandTitle || 'RC Sindhri';
            if (existingSvg) existingSvg.style.display = 'none';
            logoLink.prepend(customImg);
          }
          customImg.src = customLogo;
        });
      }

      if (brandTitle) {
        document.querySelectorAll('.nav-logo-svg text[font-weight="900"]').forEach(el => {
          el.textContent = brandTitle.toUpperCase();
        });
      }
      if (brandSubtitle) {
        document.querySelectorAll('.nav-logo-svg text[font-weight="500"], .nav-logo-svg text[font-weight="600"]').forEach(el => {
          el.textContent = brandSubtitle;
        });
      }
    },

    // 2. Announcements Banner Sync
    applyAnnouncement() {
      const banner = this.contentMap['announcement_banner'];
      if (!banner) return;

      const annBanner = document.querySelector('.announcement-banner');
      if (!annBanner) return;

      if (banner.metadata && banner.metadata.is_active === false) {
        annBanner.style.display = 'none';
        return;
      }

      const annText = annBanner.querySelector('.announcement-text, span');
      if (annText && banner.content) {
        const fullMsg = banner.title ? `${banner.title} • ${banner.content}` : banner.content;
        annText.innerHTML = fullMsg;
      }
    },

    // 3. Hero Titles, Slogans & Descriptions
    applyHeroContent() {
      const page = this.getCurrentPage();

      // Homepage Hero
      if (page === 'index') {
        const hero = this.contentMap['home_hero'];
        if (hero) {
          if (hero.title) {
            const h1 = document.querySelector('.hero-title, .hero h1');
            if (h1) h1.innerHTML = hero.title;
          }
          if (hero.subtitle) {
            const sub = document.querySelector('.hero-sub');
            if (sub) sub.innerHTML = hero.subtitle;
          }
          if (hero.content) {
            const desc = document.querySelector('.hero-desc');
            if (desc) desc.innerHTML = hero.content;
          }
        }
      }

      // About Page Hero
      if (page === 'about') {
        const aboutHero = this.contentMap['about_hero'];
        if (aboutHero) {
          if (aboutHero.title) {
            const titleEl = document.getElementById('heroTitle') || document.querySelector('.page-hero h1');
            if (titleEl) titleEl.innerHTML = aboutHero.title;
          }
          if (aboutHero.subtitle) {
            const subEl = document.querySelector('.hero-subtitle');
            if (subEl) subEl.innerHTML = aboutHero.subtitle;
          }
          if (aboutHero.content) {
            const descEl = document.querySelector('.hero-desc');
            if (descEl) descEl.innerHTML = aboutHero.content;
          }
        }
      }

      // PTY Page Hero
      if (page === 'pty') {
        const ptyHero = this.contentMap['pty_hero'];
        if (ptyHero) {
          if (ptyHero.title) {
            const titleEl = document.querySelector('.hero h1');
            if (titleEl) titleEl.innerHTML = ptyHero.title;
          }
          if (ptyHero.subtitle || ptyHero.content) {
            const pEl = document.querySelector('.hero p');
            if (pEl) pEl.innerHTML = ptyHero.subtitle || ptyHero.content;
          }
        }
      }

      // Outreach Page Hero
      if (page === 'outreach') {
        const outHero = this.contentMap['outreach_hero'];
        if (outHero) {
          if (outHero.title) {
            const titleEl = document.querySelector('.hero h1');
            if (titleEl) titleEl.innerHTML = outHero.title;
          }
          if (outHero.subtitle) {
            const subEl = document.querySelector('.hero p:first-of-type');
            if (subEl) subEl.innerHTML = outHero.subtitle;
          }
        }
      }

      // Programs Page Hero
      if (page === 'programs') {
        const progHero = this.contentMap['programs_hero'];
        if (progHero) {
          if (progHero.title) {
            const titleEl = document.querySelector('.hero h1, .page-hero h1');
            if (titleEl) titleEl.innerHTML = progHero.title;
          }
          if (progHero.subtitle) {
            const subEl = document.querySelector('.hero p, .page-hero p');
            if (subEl) subEl.innerHTML = progHero.subtitle;
          }
        }
      }

      // Contact Page Hero
      if (page === 'contact') {
        const contactHero = this.contentMap['contact_hero'];
        if (contactHero) {
          if (contactHero.title) {
            const titleEl = document.querySelector('.hero h1, .page-hero h1');
            if (titleEl) titleEl.innerHTML = contactHero.title;
          }
          if (contactHero.subtitle) {
            const subEl = document.querySelector('.hero p, .page-hero p');
            if (subEl) subEl.innerHTML = contactHero.subtitle;
          }
        }
      }

      // Gallery Page Hero
      if (page === 'gallery') {
        const galHero = this.contentMap['gallery_hero'];
        if (galHero) {
          if (galHero.title) {
            const titleEl = document.querySelector('.hero h1, .page-hero h1');
            if (titleEl) titleEl.innerHTML = galHero.title;
          }
          if (galHero.subtitle) {
            const subEl = document.querySelector('.hero p, .page-hero p');
            if (subEl) subEl.innerHTML = galHero.subtitle;
          }
        }
      }

      // Projects Page Hero
      if (page === 'projects') {
        const projHero = this.contentMap['projects_hero'];
        if (projHero) {
          if (projHero.title) {
            const titleEl = document.querySelector('.hero h1, .page-hero h1');
            if (titleEl) titleEl.innerHTML = projHero.title;
          }
          if (projHero.subtitle) {
            const subEl = document.querySelector('.hero p, .page-hero p');
            if (subEl) subEl.innerHTML = projHero.subtitle;
          }
          if (projHero.content) {
            const descEl = document.querySelector('.hero-desc, .page-hero p.lead');
            if (descEl) descEl.innerHTML = projHero.content;
          }
        }
      }

      // MANZIL Page Hero
      if (page === 'manzil') {
        const manzilHero = this.contentMap['manzil_hero'];
        if (manzilHero) {
          if (manzilHero.title) {
            const titleEl = document.querySelector('.hero h1, .page-hero h1');
            if (titleEl) titleEl.innerHTML = manzilHero.title;
          }
          if (manzilHero.subtitle) {
            const subEl = document.querySelector('.hero p, .page-hero p');
            if (subEl) subEl.innerHTML = manzilHero.subtitle;
          }
          if (manzilHero.content) {
            const descEl = document.querySelector('.hero-desc, .page-hero p.lead');
            if (descEl) descEl.innerHTML = manzilHero.content;
          }
        }
      }

      // Education Page Hero
      if (page === 'education') {
        const eduHero = this.contentMap['education_hero'];
        if (eduHero) {
          if (eduHero.title) {
            const titleEl = document.querySelector('.hero h1, .page-hero h1');
            if (titleEl) titleEl.innerHTML = eduHero.title;
          }
          if (eduHero.subtitle) {
            const subEl = document.querySelector('.hero p, .page-hero p');
            if (subEl) subEl.innerHTML = eduHero.subtitle;
          }
          if (eduHero.content) {
            const descEl = document.querySelector('.hero-desc, .page-hero p.lead');
            if (descEl) descEl.innerHTML = eduHero.content;
          }
        }
      }

      // Reports Page Hero
      if (page === 'reports') {
        const repHero = this.contentMap['reports_hero'];
        if (repHero) {
          if (repHero.title) {
            const titleEl = document.querySelector('.hero h1, .page-hero h1');
            if (titleEl) titleEl.innerHTML = repHero.title;
          }
          if (repHero.subtitle) {
            const subEl = document.querySelector('.hero p, .page-hero p');
            if (subEl) subEl.innerHTML = repHero.subtitle;
          }
        }
      }
    },

    // 4. Page Hero Cover Pictures
    applyPageCovers() {
      const page = this.getCurrentPage();
      const covers = this.contentMap['page_covers']?.metadata || {};

      // Home Hero Background
      if (page === 'index' && (covers.home_cover || this.settingsMap['home_cover'])) {
        const coverUrl = covers.home_cover || this.settingsMap['home_cover'];
        const heroSection = document.querySelector('.hero');
        if (heroSection) {
          heroSection.style.backgroundImage = `linear-gradient(rgba(13,43,26,0.85), rgba(13,27,42,0.88)), url('${coverUrl}')`;
          heroSection.style.backgroundSize = 'cover';
          heroSection.style.backgroundPosition = 'center';
        }
      }

      // About Page Cover
      if (page === 'about' && (covers.about_cover || this.settingsMap['about_cover'])) {
        const coverUrl = covers.about_cover || this.settingsMap['about_cover'];
        const coverImg = document.querySelector('.hero-cover-img, img[src*="rc-about-cover"]');
        if (coverImg) coverImg.src = coverUrl;
      }

      // PTY Page Cover
      if (page === 'pty' && (covers.pty_cover || this.settingsMap['pty_cover'])) {
        const coverUrl = covers.pty_cover || this.settingsMap['pty_cover'];
        const heroSection = document.querySelector('.hero');
        if (heroSection) {
          heroSection.style.backgroundImage = `linear-gradient(rgba(13,43,26,0.85), rgba(13,27,42,0.88)), url('${coverUrl}')`;
          heroSection.style.backgroundSize = 'cover';
        }
      }

      // Outreach Page Cover
      if (page === 'outreach' && (covers.outreach_cover || this.settingsMap['outreach_cover'])) {
        const coverUrl = covers.outreach_cover || this.settingsMap['outreach_cover'];
        const coverImgs = document.querySelectorAll('img[src*="rc-outreach-cover"]');
        coverImgs.forEach(img => { img.src = coverUrl; });
      }

      // Programs Page Cover
      if (page === 'programs' && (covers.programs_cover || this.settingsMap['programs_cover'])) {
        const coverUrl = covers.programs_cover || this.settingsMap['programs_cover'];
        const coverImg = document.querySelector('.hero-cover-img, img[src*="rc-programs-cover"]');
        if (coverImg) coverImg.src = coverUrl;
      }

      // Gallery Page Cover
      if (page === 'gallery' && (covers.gallery_cover || this.settingsMap['gallery_cover'])) {
        const coverUrl = covers.gallery_cover || this.settingsMap['gallery_cover'];
        const coverImg = document.querySelector('.hero-cover-img, img[src*="rc-gallery-cover"]');
        if (coverImg) coverImg.src = coverUrl;
      }

      // Geographic Context Satellite Map (Homepage)
      const mapPic = covers.satellite_map_pic || this.settingsMap['satellite_map_pic'];
      const mapWrapper = document.getElementById('satellite-map-wrapper');
      if (mapWrapper) {
        let customMapImg = document.getElementById('custom-satellite-img');
        const defaultSvg = document.getElementById('default-satellite-svg');
        if (mapPic && mapPic.trim() !== '') {
          if (!customMapImg) {
            customMapImg = document.createElement('img');
            customMapImg.id = 'custom-satellite-img';
            customMapImg.style.width = '100%';
            customMapImg.style.maxHeight = '520px';
            customMapImg.style.objectFit = 'contain';
            customMapImg.style.borderRadius = '12px';
            customMapImg.style.display = 'block';
            customMapImg.style.border = '1px solid #1e3a2b';
            customMapImg.alt = 'Geographic Context Satellite Map - UC Sindhri';
            mapWrapper.appendChild(customMapImg);
          }
          customMapImg.src = mapPic;
          customMapImg.style.display = 'block';
          if (defaultSvg) defaultSvg.style.display = 'none';
        } else {
          if (customMapImg) customMapImg.style.display = 'none';
          if (defaultSvg) defaultSvg.style.display = 'block';
        }
      }
    },

    // 5. Our Impact in Numbers
    applyStatistics() {
      if (!this.statsMap || Object.keys(this.statsMap).length === 0) return;
      const s = this.statsMap;

      const mapping = {
        'Vocational Trainees': s.trainees,
        'Youth Groups': s.youth_groups,
        'Youth Members': s.youth_members,
        'Awareness Sessions': s.awareness_sessions,
        'Stage Drama Performances': s.stage_drama,
        'CNIC / NADRA Cards Facilitated': s.nic_cards,
        'Youth Earning Through Trades': s.livelihoods,
        'Youth Businesses Started': s.livelihoods,
        'Villages Covered Across UC': s.villages,
        'Climate Champions': s.climate_youth || '100',
        'Health Beneficiaries': s.health_reached || '560+'
      };

      // Update stat cards on homepage & impact sections
      document.querySelectorAll('.stat-card').forEach(card => {
        const label = card.querySelector('.stat-card-label')?.textContent?.trim();
        const numEl = card.querySelector('.stat-card-number');
        if (label && numEl && mapping[label]) {
          const val = mapping[label];
          const cleanNum = parseInt(val.replace(/[^0-9]/g, '')) || 0;
          const hasPlus = val.includes('+');
          numEl.setAttribute('data-target', cleanNum);
          numEl.setAttribute('data-suffix', hasPlus ? '+' : '');
          numEl.textContent = val;
        }
      });

      // Update PTY Outcome boxes & 7 Trades
      const ptyTrades = this.contentMap['pty_vocational_trades']?.metadata?.trades;
      if (ptyTrades) {
        document.querySelectorAll('.trade-card').forEach(card => {
          const nameEl = card.querySelector('.trade-name');
          const countEl = card.querySelector('.count');
          if (nameEl && countEl) {
            const name = nameEl.textContent.toLowerCase();
            if (name.includes('e-commerce') && ptyTrades.ecommerce) countEl.textContent = ptyTrades.ecommerce;
            else if (name.includes('beautician') && ptyTrades.beautician) countEl.textContent = ptyTrades.beautician;
            else if (name.includes('dress') && ptyTrades.dressmaking) countEl.textContent = ptyTrades.dressmaking;
            else if (name.includes('solar') && ptyTrades.solar) countEl.textContent = ptyTrades.solar;
            else if (name.includes('mobile') && ptyTrades.mobile) countEl.textContent = ptyTrades.mobile;
            else if (name.includes('embroidery') && ptyTrades.embroidery) countEl.textContent = ptyTrades.embroidery;
            else if (name.includes('masonry') && ptyTrades.masonry) countEl.textContent = ptyTrades.masonry;
          }
        });
      }

      // Update PTY Outcomes (Wage employment & businesses)
      document.querySelectorAll('.outcome-box').forEach(box => {
        const text = box.textContent.toLowerCase();
        const numEl = box.querySelector('.big-num');
        if (numEl && s.livelihoods) {
          if (text.includes('earning') || text.includes('livelihood') || text.includes('wage') || text.includes('business')) {
            numEl.textContent = s.livelihoods;
          }
        }
      });

      const dramaStat = document.querySelector('.drama-stat-item .num');
      if (dramaStat && s.stage_drama) {
        dramaStat.textContent = s.stage_drama;
      }
    },

    // 6. Contact Information & Office Details
    applyContactInfo() {
      const contact = this.contentMap['contact_info'];
      if (!contact) return;

      const address = contact.title;
      const phone = contact.subtitle;
      const email = contact.content;
      const mapsUrl = contact.metadata?.maps_url;

      if (address) {
        document.querySelectorAll('[data-contact="address"], .contact-address, .footer-address').forEach(el => {
          el.textContent = address;
        });
      }

      if (phone) {
        document.querySelectorAll('[data-contact="phone"], .contact-phone, a[href^="tel:"]').forEach(el => {
          if (el.tagName === 'A') el.href = `tel:${phone.replace(/[^0-9+]/g, '')}`;
          el.textContent = phone;
        });
      }

      if (email) {
        document.querySelectorAll('[data-contact="email"], .contact-email, a[href^="mailto:"]').forEach(el => {
          if (el.tagName === 'A') el.href = `mailto:${email}`;
          el.textContent = email;
        });
      }

      if (mapsUrl) {
        document.querySelectorAll('[data-contact="maps"], a[href*="maps.app.goo.gl"], a[href*="google.com/maps"]').forEach(el => {
          el.href = mapsUrl;
        });
      }
    },

    // 7. About RC Mission, Vision & Core Values
    applyAboutContent() {
      const about = this.contentMap['about_mission'];
      if (!about) return;

      const missionEl = document.getElementById('mission-content') || document.querySelector('[data-cms="mission"]');
      if (missionEl && about.title) missionEl.innerHTML = about.title;

      const visionEl = document.getElementById('vision-content') || document.querySelector('[data-cms="vision"]');
      if (visionEl && about.subtitle) visionEl.innerHTML = about.subtitle;

      const valuesEl = document.getElementById('values-content') || document.querySelector('[data-cms="values"]');
      if (valuesEl && about.content) valuesEl.innerHTML = about.content;
    },

    // 8. Footer & Social Links
    applyFooterSocial() {
      const footer = this.contentMap['footer_social'];
      if (!footer) return;

      if (footer.title) {
        document.querySelectorAll('.footer-copyright, .footer-bottom p, .site-footer-copy').forEach(el => {
          el.innerHTML = footer.title;
        });
      }

      const waLink = footer.metadata?.whatsapp;
      const fbLink = footer.metadata?.facebook;

      if (waLink) {
        document.querySelectorAll('a[href*="chat.whatsapp.com"], a[href*="wa.me"]').forEach(el => {
          el.href = waLink;
        });
      }
      if (fbLink) {
        document.querySelectorAll('a[href*="facebook.com"]').forEach(el => {
          el.href = fbLink;
        });
      }
    },

    getCurrentPage() {
      const path = window.location.pathname.toLowerCase();
      if (path.includes('about')) return 'about';
      if (path.includes('pty')) return 'pty';
      if (path.includes('outreach')) return 'outreach';
      if (path.includes('programs')) return 'programs';
      if (path.includes('gallery')) return 'gallery';
      if (path.includes('contact')) return 'contact';
      if (path.includes('manzil')) return 'manzil';
      if (path.includes('education')) return 'education';
      if (path.includes('reports')) return 'reports';
      return 'index';
    }
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => LiveSync.init());
  } else {
    LiveSync.init();
  }

  window.RCLiveSync = LiveSync;
})();
