@echo off
title RC Sindhri Server
echo ========================================================
echo Starting RC Sindhri Web & Admin Server...
echo ========================================================
echo.
node server.js
pause
