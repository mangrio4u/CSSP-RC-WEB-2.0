// admin/admin.js - Enterprise Admin Panel Engine for RC Sindhri
// Supports real backend API communication, Supabase, and graceful local fallback

const AdminApp = {
  user: null,
  searchDebounce: null,

  async init() {
    // Verify Session - If on login page, clear tokens and exit without injecting UI
    const isLoginPage = window.location.pathname.includes('login') || window.location.href.includes('login');
    if (isLoginPage) {
      sessionStorage.removeItem('rc_admin_token');
      sessionStorage.removeItem('rc_admin_user');
      localStorage.removeItem('rc_admin_token');
      localStorage.removeItem('rc_admin_user');
      return;
    }

    this.injectGlobalUI();
    this.setupDateDisplay();

    const authStatus = await this.checkAuth();
    if (!authStatus) {
      window.location.href = 'login.html';
      return;
    }

    this.renderUserInfo();
    this.loadBadges();
    this.setupEventListeners();
  },

  async checkAuth() {
    try {
      const token = sessionStorage.getItem('rc_admin_token') || localStorage.getItem('rc_admin_token');
      if (!token) return false;

      // Allow file:// protocol and local dev sessions without backend server dependency
      if (window.location.protocol === 'file:' || (token && token.startsWith('local_dev_token_'))) {
        try {
          this.user = JSON.parse(sessionStorage.getItem('rc_admin_user') || localStorage.getItem('rc_admin_user')) || {
            email: 'rcsindhri@gmail.com',
            name: 'RC Sindhri Admin',
            role: 'superadmin'
          };
        } catch (e) {
          this.user = { email: 'rcsindhri@gmail.com', name: 'RC Sindhri Admin', role: 'superadmin' };
        }
        return true;
      }

      const headers = { 'Authorization': `Bearer ${token}` };

      try {
        const res = await fetch('/api/auth/me', { headers });
        if (res.ok) {
          const data = await res.json();
          if (data.authenticated && data.user) {
            this.user = data.user;
            return true;
          }
        }
        // Server responded but not authenticated — clear tokens and redirect
        sessionStorage.removeItem('rc_admin_token');
        sessionStorage.removeItem('rc_admin_user');
        localStorage.removeItem('rc_admin_token');
        localStorage.removeItem('rc_admin_user');
        return false;
      } catch (networkErr) {
        // If server is unreachable but valid local token exists, allow offline session
        if (token) {
          try {
            this.user = JSON.parse(sessionStorage.getItem('rc_admin_user') || localStorage.getItem('rc_admin_user')) || {
              email: 'rcsindhri@gmail.com',
              name: 'RC Sindhri Admin',
              role: 'superadmin'
            };
            return true;
          } catch(e) {}
        }
        console.warn('Cannot reach authentication server:', networkErr.message);
        return false;
      }
    } catch (e) {
      return false;
    }
  },


  async logout() {
    try {
      await fetch('/api/auth/logout', { method: 'POST' });
    } catch (e) {}
    sessionStorage.removeItem('rc_admin_token');
    sessionStorage.removeItem('rc_admin_user');
    localStorage.removeItem('rc_admin_token');
    localStorage.removeItem('rc_admin_user');
    window.location.href = 'login.html';
  },

  renderUserInfo() {
    const userEl = document.getElementById('sidebar-user-name');
    const headerUserEl = document.getElementById('header-user-name');
    if (this.user) {
      const name = this.user.name || this.user.full_name || this.user.email;
      if (userEl) userEl.innerText = name;
      if (headerUserEl) headerUserEl.innerText = name;
    }
  },

  setupDateDisplay() {
    const dateEl = document.getElementById('current-date-text');
    if (dateEl) {
      const now = new Date();
      const options = { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' };
      dateEl.innerText = now.toLocaleDateString('en-GB', options);
    }
  },

  async loadBadges() {
    try {
      const res = await this.fetchWithAuth('/api/stats');
      if (res.ok) {
        const data = await res.json();
        const pendingBadge = document.getElementById('pending-badge');
        if (pendingBadge && data.stats) {
          const count = data.stats.pending_submissions || 0;
          pendingBadge.innerText = count;
          pendingBadge.style.display = count > 0 ? 'inline-block' : 'none';
        }

        const notifBadge = document.getElementById('header-notif-badge');
        if (notifBadge && data.stats) {
          const notifCount = data.stats.unread_notifications_count || 0;
          notifBadge.style.display = notifCount > 0 ? 'block' : 'none';
        }
      }
    } catch (e) {}
  },

  async fetchWithAuth(url, options = {}) {
    options.headers = options.headers || {};
    const token = sessionStorage.getItem('rc_admin_token') || localStorage.getItem('rc_admin_token');
    if (token) {
      options.headers['Authorization'] = `Bearer ${token}`;
    }
    if (options.body && !(options.body instanceof FormData) && !options.headers['Content-Type']) {
      options.headers['Content-Type'] = 'application/json';
    }
    const fullUrl = (window.location.protocol === 'file:' && url.startsWith('/')) ? 'http://localhost:3000' + url : url;
    return fetch(fullUrl, options);
  },

  // ------------------------------------------------------------------------------
  // GLOBAL UI INJECTION (Search Modal, Confirm Modal, Toast Container)
  // ------------------------------------------------------------------------------
  injectGlobalUI() {
    // 1. Toast Container
    if (!document.getElementById('toast-container')) {
      const tc = document.createElement('div');
      tc.id = 'toast-container';
      document.body.appendChild(tc);
    }

    // 2. Mobile Backdrop
    if (!document.getElementById('sidebar-backdrop')) {
      const sb = document.createElement('div');
      sb.id = 'sidebar-backdrop';
      sb.className = 'sidebar-backdrop';
      sb.onclick = () => this.toggleMobileSidebar(false);
      document.body.appendChild(sb);
    }

    // 3. Global Search Modal (Ctrl + K)
    if (!document.getElementById('global-search-modal')) {
      const searchModal = document.createElement('div');
      searchModal.id = 'global-search-modal';
      searchModal.className = 'modal-overlay';
      searchModal.innerHTML = `
        <div class="modal-card search-modal-card">
          <div class="search-modal-input-wrap">
            <i class="fa-solid fa-magnifying-glass" style="color:#64748b; font-size:1.15rem;"></i>
            <input type="text" id="global-search-input" class="search-modal-input" placeholder="Search activities, programs, albums, committee, statistics..." autocomplete="off" />
            <button onclick="AdminApp.closeSearch()" style="background:none; border:none; color:#94a3b8; font-size:1.2rem; cursor:pointer;"><i class="fa-solid fa-xmark"></i></button>
          </div>
          <div class="search-results-list" id="search-results-box">
            <div style="padding: 2.5rem; text-align: center; color: #94a3b8;">
              <i class="fa-solid fa-keyboard" style="font-size: 2rem; margin-bottom: 0.5rem; display: block; opacity: 0.4;"></i>
              Type at least 2 characters to search across activities, programs, albums, committee, and statistics.
            </div>
          </div>
        </div>
      `;
      document.body.appendChild(searchModal);
    }

    // 4. Confirm Dialog Modal
    if (!document.getElementById('global-confirm-modal')) {
      const confirmModal = document.createElement('div');
      confirmModal.id = 'global-confirm-modal';
      confirmModal.className = 'modal-overlay';
      confirmModal.innerHTML = `
        <div class="modal-card" style="max-width:440px;">
          <div class="modal-header">
            <h3 class="modal-title" id="confirm-modal-title">Confirm Action</h3>
            <button onclick="AdminApp.closeConfirm()" class="modal-close-btn">&times;</button>
          </div>
          <div class="modal-body" id="confirm-modal-body" style="font-size:0.95rem; color:#475569;">
            Are you sure you want to proceed?
          </div>
          <div class="modal-footer">
            <button onclick="AdminApp.closeConfirm()" class="btn btn-outline">Cancel</button>
            <button id="confirm-modal-btn" class="btn btn-danger">Confirm</button>
          </div>
        </div>
      `;
      document.body.appendChild(confirmModal);
    }

    // Attach global modal helper functions if not present
    if (!window.openModal) {
      window.openModal = (id) => {
        const el = document.getElementById(id);
        if (el) el.classList.add('active');
      };
    }
    if (!window.closeModal) {
      window.closeModal = (id) => {
        const el = document.getElementById(id);
        if (el) el.classList.remove('active');
      };
    }

    // Close any modal when clicking on the overlay background
    document.addEventListener('click', (e) => {
      if (e.target && e.target.classList && e.target.classList.contains('modal-overlay')) {
        e.target.classList.remove('active');
      }
    });
  },

  setupEventListeners() {
    // Mobile sidebar toggle buttons (supports all button selectors)
    document.querySelectorAll('.sidebar-toggle-btn, .nav-toggle-btn, #nav-toggle-btn').forEach(btn => {
      btn.onclick = (e) => {
        e.stopPropagation();
        this.toggleMobileSidebar();
      };
    });

    // Highlight current active page in sidebar
    try {
      const pageName = window.location.pathname.split('/').pop() || 'index.html';
      document.querySelectorAll('.sidebar-nav .nav-link').forEach(link => {
        const href = link.getAttribute('href');
        if (href && (href === pageName || href.endsWith(pageName))) {
          document.querySelectorAll('.sidebar-nav .nav-link').forEach(l => l.classList.remove('active'));
          link.classList.add('active');
        }
      });
    } catch (e) {}

    // Keyboard shortcuts: Ctrl+K and Escape
    window.addEventListener('keydown', (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        this.openSearch();
      }
      if (e.key === 'Escape') {
        this.closeSearch();
        this.closeConfirm();
        this.closeDropdowns();
        this.toggleMobileSidebar(false);
        document.querySelectorAll('.modal-overlay.active').forEach(m => m.classList.remove('active'));
      }
    });

    // Profile Dropdown Toggle
    const profileBtn = document.getElementById('admin-profile-btn');
    const profileDropdown = document.getElementById('profile-dropdown-menu');
    if (profileBtn && profileDropdown) {
      profileBtn.onclick = (e) => {
        e.stopPropagation();
        profileDropdown.classList.toggle('show');
        const notifDropdown = document.getElementById('notifications-dropdown-menu');
        if (notifDropdown) notifDropdown.classList.remove('show');
      };
    }

    // Notifications Dropdown Toggle
    const notifBtn = document.getElementById('header-notif-btn');
    const notifDropdown = document.getElementById('notifications-dropdown-menu');
    if (notifBtn && notifDropdown) {
      notifBtn.onclick = (e) => {
        e.stopPropagation();
        notifDropdown.classList.toggle('show');
        if (profileDropdown) profileDropdown.classList.remove('show');
        this.loadNotifications();
      };
    }

    // Close dropdowns on outside click
    document.addEventListener('click', () => {
      this.closeDropdowns();
    });

    // Global Search Input Handler
    const searchInput = document.getElementById('global-search-input');
    if (searchInput) {
      searchInput.oninput = (e) => {
        clearTimeout(this.searchDebounce);
        const query = e.target.value.trim();
        this.searchDebounce = setTimeout(() => this.executeSearch(query), 200);
      };
    }
  },

  closeDropdowns() {
    const p = document.getElementById('profile-dropdown-menu');
    const n = document.getElementById('notifications-dropdown-menu');
    if (p) p.classList.remove('show');
    if (n) n.classList.remove('show');
  },

  toggleMobileSidebar(forceState) {
    const sidebar = document.querySelector('.admin-sidebar');
    let backdrop = document.getElementById('sidebar-backdrop');
    if (!backdrop) {
      backdrop = document.createElement('div');
      backdrop.id = 'sidebar-backdrop';
      backdrop.className = 'sidebar-backdrop';
      backdrop.onclick = () => this.toggleMobileSidebar(false);
      document.body.appendChild(backdrop);
    }
    if (!sidebar) return;

    const isOpen = forceState !== undefined ? forceState : !sidebar.classList.contains('open');
    if (isOpen) {
      sidebar.classList.add('open');
      backdrop.classList.add('active');
    } else {
      sidebar.classList.remove('open');
      backdrop.classList.remove('active');
    }
  },

  // ------------------------------------------------------------------------------
  // GLOBAL SEARCH (Ctrl + K)
  // ------------------------------------------------------------------------------
  openSearch() {
    const modal = document.getElementById('global-search-modal');
    const input = document.getElementById('global-search-input');
    if (modal) {
      modal.classList.add('active');
      if (input) {
        input.value = '';
        setTimeout(() => input.focus(), 50);
      }
    }
  },

  closeSearch() {
    const modal = document.getElementById('global-search-modal');
    if (modal) modal.classList.remove('active');
  },

  async executeSearch(query) {
    const box = document.getElementById('search-results-box');
    if (!box) return;

    if (!query || query.length < 2) {
      box.innerHTML = `
        <div style="padding: 2.5rem; text-align: center; color: #94a3b8;">
          <i class="fa-solid fa-keyboard" style="font-size: 2rem; margin-bottom: 0.5rem; display: block; opacity: 0.4;"></i>
          Type at least 2 characters to search across candidates, jobs, employers, and applications.
        </div>
      `;
      return;
    }

    box.innerHTML = `<div style="padding:2rem; text-align:center; color:#94a3b8;"><i class="fa-solid fa-spinner fa-spin"></i> Searching...</div>`;

    try {
      const res = await this.fetchWithAuth(`/api/search?q=${encodeURIComponent(query)}`);
      if (!res.ok) throw new Error('Search failed');
      const data = await res.json();
      const { members = [], activities = [], programs = [], albums = [], statistics = [] } = data.results || {};

      const hasResults = members.length || activities.length || programs.length || albums.length || statistics.length;

      if (!hasResults) {
        box.innerHTML = `
          <div style="padding: 2rem; text-align: center; color: #94a3b8;">
            <i class="fa-solid fa-magnifying-glass" style="font-size: 1.8rem; margin-bottom: 0.5rem; display: block; opacity: 0.4;"></i>
            No results found for "<strong>${this.escapeHtml(query)}</strong>".
          </div>
        `;
        return;
      }

      let html = '';

      if (members.length) {
        html += `<div class="search-group-title"><i class="fa-solid fa-user-group"></i> Members (${members.length})</div>`;
        members.forEach(m => {
          const targetPage = (m.committee_type === 'management') ? 'committee.html' : 'members.html';
          html += `
            <a href="${targetPage}?id=${m.id}" class="search-result-item" onclick="AdminApp.closeSearch()">
              <div>
                <strong style="display:block;">${this.escapeHtml(m.full_name)}</strong>
                <span style="font-size:0.75rem; color:#64748b;">${this.escapeHtml(m.designation_title || '')} • ${this.escapeHtml(m.committee_type || 'Team')}</span>
              </div>
              <span class="status-badge badge-active">${this.escapeHtml(m.status || 'Active')}</span>
            </a>
          `;
        });
      }

      if (activities.length) {
        html += `<div class="search-group-title"><i class="fa-solid fa-calendar-check"></i> Activities (${activities.length})</div>`;
        activities.forEach(a => {
          html += `
            <a href="activities.html?id=${a.id}" class="search-result-item" onclick="AdminApp.closeSearch()">
              <div>
                <strong style="display:block;">${this.escapeHtml(a.title)}</strong>
                <span style="font-size:0.75rem; color:#64748b;">${this.escapeHtml(a.activity_type)} • ${this.escapeHtml(a.location || a.village_name || '')}</span>
              </div>
              <span class="status-badge badge-active">${this.escapeHtml(a.status || 'Completed')}</span>
            </a>
          `;
        });
      }

      if (programs.length) {
        html += `<div class="search-group-title"><i class="fa-solid fa-folder-open"></i> Programs (${programs.length})</div>`;
        programs.forEach(p => {
          html += `
            <a href="programs.html?id=${p.id}" class="search-result-item" onclick="AdminApp.closeSearch()">
              <div>
                <strong style="display:block;">${this.escapeHtml(p.name)}</strong>
                <span style="font-size:0.75rem; color:#64748b;">${this.escapeHtml(p.project_type || 'Initiative')}</span>
              </div>
              <span class="status-badge badge-active">${this.escapeHtml(p.status || 'Active')}</span>
            </a>
          `;
        });
      }

      if (albums.length) {
        html += `<div class="search-group-title"><i class="fa-solid fa-images"></i> Albums (${albums.length})</div>`;
        albums.forEach(al => {
          html += `
            <a href="albums.html?id=${al.id}" class="search-result-item" onclick="AdminApp.closeSearch()">
              <div>
                <strong style="display:block;">${this.escapeHtml(al.title)}</strong>
                <span style="font-size:0.75rem; color:#64748b;">Slug: ${this.escapeHtml(al.slug)}</span>
              </div>
              <span class="status-badge badge-active">Album</span>
            </a>
          `;
        });
      }

      if (statistics.length) {
        html += `<div class="search-group-title"><i class="fa-solid fa-chart-line"></i> Statistics (${statistics.length})</div>`;
        statistics.forEach(s => {
          html += `
            <a href="statistics.html?key=${s.stat_key}" class="search-result-item" onclick="AdminApp.closeSearch()">
              <div>
                <strong style="display:block;">${this.escapeHtml(s.label)}: ${this.escapeHtml(s.display_value)}</strong>
                <span style="font-size:0.75rem; color:#64748b;">Key: ${this.escapeHtml(s.stat_key)}</span>
              </div>
              <span class="status-badge badge-active">Stat</span>
            </a>
          `;
        });
      }

      box.innerHTML = html;
    } catch (e) {
      box.innerHTML = `<div style="padding:1.5rem; text-align:center; color:#ef4444;">Search request error.</div>`;
    }
  },

  // ------------------------------------------------------------------------------
  // NOTIFICATIONS
  // ------------------------------------------------------------------------------
  async loadNotifications() {
    const list = document.getElementById('notifications-list');
    if (!list) return;

    try {
      const res = await this.fetchWithAuth('/api/notifications');
      if (!res.ok) throw new Error('Failed to load notifications');
      const data = await res.json();
      const notifications = data.notifications || [];

      if (!notifications.length) {
        list.innerHTML = `<div style="padding:1.5rem; text-align:center; color:#94a3b8; font-size:0.85rem;">No notifications right now.</div>`;
        return;
      }

      list.innerHTML = notifications.slice(0, 6).map(n => `
        <div style="padding:0.75rem 1rem; border-bottom:1px solid #f1f5f9; display:flex; gap:0.65rem; align-items:flex-start;">
          <i class="fa-solid fa-bell" style="color:#1677E8; font-size:0.85rem; margin-top:3px;"></i>
          <div style="flex:1;">
            <div style="font-weight:600; font-size:0.82rem; color:#0f172a;">${this.escapeHtml(n.title)}</div>
            <div style="font-size:0.75rem; color:#64748b; margin-top:1px;">${this.escapeHtml(n.message)}</div>
            <span style="font-size:0.68rem; color:#94a3b8;">${this.formatRelativeTime(n.created_at)}</span>
          </div>
        </div>
      `).join('');
    } catch (e) {}
  },

  async markAllNotificationsRead() {
    try {
      await this.fetchWithAuth('/api/notifications', { method: 'PUT', body: JSON.stringify({ id: 'all' }) });
      this.toast('All notifications marked as read', 'success');
      const badge = document.getElementById('header-notif-badge');
      if (badge) badge.style.display = 'none';
      this.loadNotifications();
    } catch (e) {}
  },

  // ------------------------------------------------------------------------------
  // CONFIRM DIALOG
  // ------------------------------------------------------------------------------
  confirm(title, message, onConfirm) {
    const modal = document.getElementById('global-confirm-modal');
    const titleEl = document.getElementById('confirm-modal-title');
    const bodyEl = document.getElementById('confirm-modal-body');
    const btn = document.getElementById('confirm-modal-btn');

    if (modal && titleEl && bodyEl && btn) {
      titleEl.innerText = title;
      bodyEl.innerText = message;
      btn.onclick = async () => {
        this.closeConfirm();
        if (typeof onConfirm === 'function') await onConfirm();
      };
      modal.classList.add('active');
    }
  },

  closeConfirm() {
    const modal = document.getElementById('global-confirm-modal');
    if (modal) modal.classList.remove('active');
  },

  // ------------------------------------------------------------------------------
  // TOASTS & UTILS
  // ------------------------------------------------------------------------------
  toast(message, type = 'info') {
    const container = document.getElementById('toast-container');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = `toast ${type}`;

    let icon = 'fa-info-circle';
    if (type === 'success') icon = 'fa-circle-check';
    if (type === 'error') icon = 'fa-triangle-exclamation';
    if (type === 'warning') icon = 'fa-bell';

    toast.innerHTML = `<i class="fa-solid ${icon}" style="font-size:1.1rem;"></i> <span>${this.escapeHtml(message)}</span>`;
    container.appendChild(toast);

    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateY(10px)';
      toast.style.transition = 'all 0.2s ease';
      setTimeout(() => toast.remove(), 200);
    }, 3500);
  },

  escapeHtml(str) {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  },

  formatRelativeTime(isoStr) {
    if (!isoStr) return '';
    const diff = Date.now() - new Date(isoStr).getTime();
    const minutes = Math.floor(diff / 60000);
    if (minutes < 1) return 'Just now';
    if (minutes < 60) return `${minutes} min ago`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours} hour${hours > 1 ? 's' : ''} ago`;
    const days = Math.floor(hours / 24);
    return `${days} day${days > 1 ? 's' : ''} ago`;
  }
};

// Global shorthand
function escapeHtml(str) {
  return AdminApp.escapeHtml(str);
}

document.addEventListener('DOMContentLoaded', () => {
  AdminApp.init();
});
