// test/test_api.js - Automated Test Suite for RC Sindhri Admin & Gallery Backend
require('../lib/env');

const http = require('http');
const assert = require('assert');

// Load API endpoints
const loginHandler = require('../api/auth/login');
const logoutHandler = require('../api/auth/logout');
const meHandler = require('../api/auth/me');
const statsHandler = require('../api/stats');
const albumsHandler = require('../api/albums/index');
const albumsManageHandler = require('../api/albums/manage');
const submissionsHandler = require('../api/submissions/index');
const moderateHandler = require('../api/submissions/moderate');
const photosHandler = require('../api/photos/index');
const galleryHandler = require('../api/gallery');
const setupHandler = require('../api/setup');
const activitiesHandler = require('../api/activities');
const programsHandler = require('../api/programs');
const statisticsHandler = require('../api/statistics');
const contentHandler = require('../api/content');
const mediaHandler = require('../api/media');
const membersHandler = require('../api/members');
const settingsHandler = require('../api/settings');

// Mock request / response helper
function createMockReqRes(options = {}) {
  const req = {
    method: options.method || 'GET',
    url: options.url || '/',
    headers: options.headers || {},
    query: options.query || {},
    body: options.body || {},
    socket: { remoteAddress: '127.0.0.1' }
  };

  const res = {
    statusCode: 200,
    headers: {},
    body: null,
    setHeader(key, value) {
      this.headers[key.toLowerCase()] = value;
    },
    status(code) {
      this.statusCode = code;
      return this;
    },
    json(data) {
      this.body = data;
      return this;
    },
    end() {
      return this;
    }
  };

  return { req, res };
}

async function runTests() {
  console.log('🚀 Starting RC Sindhri Backend Test Suite...\n');
  let token = null;

  // 1. Test Setup / Health Endpoint
  {
    console.log('Test 1: Health & Setup Check Endpoint (/api/setup)');
    const { req, res } = createMockReqRes({ method: 'GET' });
    await setupHandler(req, res);
    assert.strictEqual(res.statusCode, 200);
    assert.strictEqual(res.body.success, true);
    assert.ok(res.body.integrations.database);
    console.log('✅ Health check passed.\n');
  }

  // 2. Test Invalid Login
  {
    console.log('Test 2: Admin Login with Invalid Password');
    const { req, res } = createMockReqRes({
      method: 'POST',
      body: { email: 'rcsindhri@gmail.com', password: 'WrongPassword123' }
    });
    await loginHandler(req, res);
    assert.strictEqual(res.statusCode, 401);
    assert.strictEqual(res.body.success, false);
    console.log('✅ Invalid login rejected correctly.\n');
  }

  // 3. Test Valid Admin Login
  {
    console.log('Test 3: Admin Login with Valid Credentials');
    const { req, res } = createMockReqRes({
      method: 'POST',
      body: { email: 'rcsindhri@gmail.com', password: 'Admin1122' }
    });
    await loginHandler(req, res);
    assert.strictEqual(res.statusCode, 200);
    assert.strictEqual(res.body.success, true);
    assert.ok(res.body.token);
    token = res.body.token;
    console.log('✅ Valid login successful. Token issued.\n');
  }

  // 4. Test Session Check (/api/auth/me)
  {
    console.log('Test 4: Verify Session (/api/auth/me)');
    const { req, res } = createMockReqRes({
      method: 'GET',
      headers: { authorization: `Bearer ${token}` }
    });
    await meHandler(req, res);
    assert.strictEqual(res.statusCode, 200);
    assert.strictEqual(res.body.authenticated, true);
    assert.strictEqual(res.body.user.email, 'rcsindhri@gmail.com');
    console.log('✅ Session verified successfully.\n');
  }

  // 5. Test Dashboard Stats
  {
    console.log('Test 5: Dashboard Statistics (/api/stats)');
    const { req, res } = createMockReqRes({
      method: 'GET',
      headers: { authorization: `Bearer ${token}` }
    });
    await statsHandler(req, res);
    assert.strictEqual(res.statusCode, 200);
    assert.strictEqual(res.body.success, true);
    assert.ok(res.body.stats.total_albums >= 0);
    console.log('✅ Stats endpoint returned accurate metrics.\n');
  }

  // 6. Test Albums Listing & Creation
  let createdAlbumId = null;
  {
    console.log('Test 6: Create New Activity Album (/api/albums)');
    const { req, res } = createMockReqRes({
      method: 'POST',
      headers: { authorization: `Bearer ${token}` },
      body: {
        title: 'Youth Sports & Athletics 2026',
        slug: 'youth-sports-2026',
        description: 'District level football and cricket tournaments in Sindhri.',
        is_visible: true,
        display_order: 10
      }
    });
    await albumsHandler(req, res);
    assert.strictEqual(res.statusCode, 201);
    assert.strictEqual(res.body.success, true);
    assert.strictEqual(res.body.album.slug, 'youth-sports-2026');
    createdAlbumId = res.body.album.id;
    console.log('✅ Album created successfully with id:', createdAlbumId, '\n');
  }

  // 7. Test Public Photo Submission
  let submissionId = null;
  {
    console.log('Test 7: Public Photo Submission (/api/submissions)');
    const { req, res } = createMockReqRes({
      method: 'POST',
      body: {
        title: 'Football Match Finals Haji Hamer',
        submitter_name: 'Imran Ali',
        submitter_email: 'imran@example.com',
        location: 'Village Haji Hamer Mangrio',
        album_id: createdAlbumId,
        description: 'Final championship match attended by 200 youth.',
        consent_given: true,
        imageUrl: 'https://images.unsplash.com/photo-1579952363873-27f3bade9f55?w=800'
      }
    });
    await submissionsHandler(req, res);
    assert.strictEqual(res.statusCode, 201);
    assert.strictEqual(res.body.success, true);
    assert.strictEqual(res.body.submission.status, 'pending');
    assert.strictEqual(res.body.submission.is_published, false);
    submissionId = res.body.submission.id;
    console.log('✅ Photo submission received with default "pending" status.\n');
  }

  // 8. Verify Pending Photo does NOT appear in Public Gallery
  {
    console.log('Test 8: Verify Pending Photo is HIDDEN from Public Gallery');
    const { req, res } = createMockReqRes({ method: 'GET' });
    await galleryHandler(req, res);
    assert.strictEqual(res.statusCode, 200);
    const inGallery = res.body.photos.some(p => p.id === submissionId);
    assert.strictEqual(inGallery, false, 'Pending photo must not be visible in gallery!');
    console.log('✅ Verified: Pending photos are strictly excluded from public gallery.\n');
  }

  // 9. Admin Approves Photo
  {
    console.log('Test 9: Admin Moderation - Approve Photo (/api/submissions/moderate)');
    const { req, res } = createMockReqRes({
      method: 'POST',
      headers: { authorization: `Bearer ${token}` },
      body: {
        id: submissionId,
        action: 'approve',
        album_id: createdAlbumId
      }
    });
    await moderateHandler(req, res);
    assert.strictEqual(res.statusCode, 200);
    assert.strictEqual(res.body.success, true);
    assert.strictEqual(res.body.photo.status, 'approved');
    assert.strictEqual(res.body.photo.is_published, true);
    console.log('✅ Photo approved and published.\n');
  }

  // 10. Verify Approved Photo APPEARS in Public Gallery
  {
    console.log('Test 10: Verify Approved Photo NOW Appears in Public Gallery');
    const { req, res } = createMockReqRes({ method: 'GET' });
    await galleryHandler(req, res);
    assert.strictEqual(res.statusCode, 200);
    const inGallery = res.body.photos.some(p => p.id === submissionId);
    assert.strictEqual(inGallery, true, 'Approved photo must now be visible in public gallery!');
    console.log('✅ Verified: Approved photo is now active in public gallery.\n');
  }

  // 11. Test Album Deletion Safety
  {
    console.log('Test 11: Safe Album Deletion (/api/albums/manage)');
    const { req, res } = createMockReqRes({
      method: 'DELETE',
      query: { id: createdAlbumId },
      headers: { authorization: `Bearer ${token}` }
    });
    await albumsManageHandler(req, res);
    assert.strictEqual(res.statusCode, 200);
    assert.strictEqual(res.body.success, true);
    console.log('✅ Album deleted safely without breaking photo records.\n');
  }

  // 12. Test Activities API (/api/activities)
  let createdActId = null;
  {
    console.log('Test 12: Activities CRUD API (/api/activities)');
    const { req, res } = createMockReqRes({
      method: 'POST',
      headers: { authorization: `Bearer ${token}` },
      body: {
        title: 'Tree Plantation Drive at Haji Hamer',
        activity_type: 'Climate',
        project_name: 'PTY — Power to Youth',
        location: 'Village Haji Hamer Mangrio',
        total_participants: 65,
        status: 'Completed'
      }
    });
    await activitiesHandler(req, res);
    assert.strictEqual(res.statusCode, 201);
    assert.strictEqual(res.body.success, true);
    assert.ok(res.body.activity.id);
    createdActId = res.body.activity.id;

    // Verify GET
    const { req: getReq, res: getRes } = createMockReqRes({ method: 'GET', query: { id: createdActId } });
    await activitiesHandler(getReq, getRes);
    assert.strictEqual(getRes.statusCode, 200);
    assert.strictEqual(getRes.body.activity.title, 'Tree Plantation Drive at Haji Hamer');
    console.log('✅ Activities CRUD verified successfully.\n');
  }

  // 13. Test Programs API (/api/programs)
  let createdProgId = null;
  {
    console.log('Test 13: Programs CRUD API (/api/programs)');
    const { req, res } = createMockReqRes({
      method: 'POST',
      headers: { authorization: `Bearer ${token}` },
      body: {
        name: 'Digital Skills for Youth',
        short_name: 'DSY',
        description: 'Computer literacy and freelancing training for Sindhri youth',
        project_type: 'Digital Skills',
        status: 'Active'
      }
    });
    await programsHandler(req, res);
    assert.strictEqual(res.statusCode, 201);
    assert.strictEqual(res.body.success, true);
    createdProgId = res.body.program.id;
    console.log('✅ Programs CRUD verified successfully.\n');
  }

  // 14. Test Website Statistics Update & Sync (/api/statistics)
  {
    console.log('Test 14: Website Statistics Sync (/api/statistics)');
    const { req, res } = createMockReqRes({
      method: 'PUT',
      headers: { authorization: `Bearer ${token}` },
      body: {
        statistics: {
          vocational_trainees: '250+',
          youth_members: '220+'
        }
      }
    });
    await statisticsHandler(req, res);
    assert.strictEqual(res.statusCode, 200);
    assert.strictEqual(res.body.success, true);

    // Verify Public GET
    const { req: getReq, res: getRes } = createMockReqRes({ method: 'GET' });
    await statisticsHandler(getReq, getRes);
    assert.strictEqual(getRes.statusCode, 200);
    assert.strictEqual(getRes.body.statistics.trainees, '250+');
    console.log('✅ Live statistics sync verified successfully.\n');
  }

  // 15. Test Website Content CMS Update (/api/content)
  {
    console.log('Test 15: Website Content CMS (/api/content)');
    const { req, res } = createMockReqRes({
      method: 'PUT',
      headers: { authorization: `Bearer ${token}` },
      body: {
        section_key: 'home_hero',
        title: 'RC SINDHRI OFFICIAL',
        subtitle: 'Empowering Communities, Transforming Futures'
      }
    });
    await contentHandler(req, res);
    assert.strictEqual(res.statusCode, 200);
    assert.strictEqual(res.body.success, true);

    // Verify Public GET
    const { req: getReq, res: getRes } = createMockReqRes({ method: 'GET' });
    await contentHandler(getReq, getRes);
    assert.strictEqual(getRes.statusCode, 200);
    const hero = getRes.body.content.find(c => c.section_key === 'home_hero');
    assert.strictEqual(hero.title, 'RC SINDHRI OFFICIAL');
    console.log('✅ Website content CMS verified successfully.\n');
  }

  // 16. Test Media Management API (/api/media)
  let createdMediaId = null;
  {
    console.log('Test 16: Media Management API (/api/media)');
    const { req, res } = createMockReqRes({
      method: 'POST',
      headers: { authorization: `Bearer ${token}` },
      body: {
        title: 'Vocational Center Front View',
        image_url: 'https://images.unsplash.com/photo-1542838132-92c53300491e?w=800',
        location: 'Haji Hamer Mangrio'
      }
    });
    await mediaHandler(req, res);
    assert.strictEqual(res.statusCode, 201);
    assert.strictEqual(res.body.success, true);
    createdMediaId = res.body.photo.id;

    // Replace photo URL
    const { req: putReq, res: putRes } = createMockReqRes({
      method: 'PUT',
      headers: { authorization: `Bearer ${token}` },
      query: { id: createdMediaId },
      body: { image_url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=800' }
    });
    await mediaHandler(putReq, putRes);
    assert.strictEqual(putRes.statusCode, 200);
    assert.strictEqual(putRes.body.success, true);
    console.log('✅ Media Management upload and replace verified.\n');
  }

  // 17. Clean up test records
  {
    if (createdActId) {
      const { req, res } = createMockReqRes({ method: 'DELETE', query: { id: createdActId }, headers: { authorization: `Bearer ${token}` } });
      await activitiesHandler(req, res);
    }
    if (createdProgId) {
      const { req, res } = createMockReqRes({ method: 'DELETE', query: { id: createdProgId }, headers: { authorization: `Bearer ${token}` } });
      await programsHandler(req, res);
    }
    if (createdMediaId) {
      const { req, res } = createMockReqRes({ method: 'DELETE', query: { id: createdMediaId }, headers: { authorization: `Bearer ${token}` } });
      await mediaHandler(req, res);
    }
  }

  // 17b. Test Site Settings & Branding API (/api/settings)
  {
    console.log('Test 17b: Site Settings & Branding API (/api/settings)');
    const { req, res } = createMockReqRes({
      method: 'PUT',
      headers: { authorization: `Bearer ${token}` },
      body: {
        settings: {
          website_title: 'RC SINDHRI TEST',
          website_subtitle: 'Rozgar Center Test Subtitle'
        }
      }
    });
    await settingsHandler(req, res);
    assert.strictEqual(res.statusCode, 200);
    assert.strictEqual(res.body.success, true);

    // Verify Public GET
    const { req: getReq, res: getRes } = createMockReqRes({ method: 'GET' });
    await settingsHandler(getReq, getRes);
    assert.strictEqual(getRes.statusCode, 200);
    assert.strictEqual(getRes.body.settings.website_title, 'RC SINDHRI TEST');
    console.log('✅ Settings & branding API verified successfully.\n');
  }

  // 18. Test Admin Logout
  {
    console.log('Test 18: Admin Logout (/api/auth/logout)');
    const { req, res } = createMockReqRes({ method: 'POST' });
    await logoutHandler(req, res);
    assert.strictEqual(res.statusCode, 200);
    assert.strictEqual(res.body.success, true);
    console.log('✅ Admin logged out successfully.\n');
  }

  console.log('🎉 ALL 18 TESTS PASSED SUCCESSFULLY! 100% Verified.');
}

runTests().catch(err => {
  console.error('❌ Test failed with error:', err);
  process.exit(1);
});
