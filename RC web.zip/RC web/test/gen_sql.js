const fs = require('fs');
const d = require('../data/store.json');
const members = d.community_members;

function esc(s) {
  return s ? String(s).replace(/'/g, "''") : '';
}

let sql = '-- 24.8 Seed 28 Verified Committee Members (Management, PTY, MANZIL, Stage Drama)\nINSERT INTO community_members (full_name, designation_title, department_area, committee_type, village_name, short_bio, display_order, status, is_public) VALUES\n';

const rows = members.map(m => {
  return `    ('${esc(m.full_name)}', '${esc(m.designation_title)}', '${esc(m.department_area)}', '${esc(m.committee_type || 'management')}', '${esc(m.village_name || 'UC Sindhri')}', '${esc(m.short_bio)}', ${m.display_order || 10}, '${m.status || 'Active'}', ${m.is_public !== false ? 'TRUE' : 'FALSE'})`;
});

sql += rows.join(',\n') + ';\n';
fs.writeFileSync('test/members_seed.sql', sql, 'utf8');
console.log('Successfully generated SQL for', members.length, 'members');
