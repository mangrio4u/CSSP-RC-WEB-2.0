// server.js - Local Development & Production Server for RC Sindhri
// Supports full static serving, clean URLs, and serverless API execution
require('./lib/env');

const http = require('http');
const fs = require('fs');
const path = require('path');
const url = require('url');

// Load environment variables from .env if present
const envPath = path.join(__dirname, '.env');
if (fs.existsSync(envPath)) {
  try {
    const envContent = fs.readFileSync(envPath, 'utf8');
    envContent.split(/\r?\n/).forEach(line => {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith('#')) return;
      const eqIdx = trimmed.indexOf('=');
      if (eqIdx !== -1) {
        const key = trimmed.slice(0, eqIdx).trim();
        let val = trimmed.slice(eqIdx + 1).trim();
        if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) {
          val = val.slice(1, -1);
        }
        if (!process.env[key]) {
          process.env[key] = val;
        }
      }
    });
  } catch (err) {
    console.warn('Could not read .env file:', err.message);
  }
}

const PORT = process.env.PORT || 3000;
const ROOT_DIR = __dirname;

const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.ico': 'image/x-icon',
  '.txt': 'text/plain; charset=utf-8',
  '.xml': 'application/xml; charset=utf-8'
};

// Route mapping for clean URLs
const CLEAN_ROUTES = {
  '/admin': '/admin/index.html',
  '/admin/': '/admin/index.html',
  '/admin/login': '/admin/login.html',
  '/admin/albums': '/admin/albums.html',
  '/admin/activities': '/admin/activities.html',
  '/admin/programs': '/admin/programs.html',
  '/admin/statistics': '/admin/statistics.html',
  '/admin/committee': '/admin/committee.html',
  '/admin/members': '/admin/members.html',
  '/admin/content': '/admin/content.html',
  '/admin/media': '/admin/media.html',
  '/admin/photos': '/admin/photos.html',
  '/admin/submissions': '/admin/submissions.html',
  '/admin/settings': '/admin/settings.html',
  '/upload-photo': '/upload-photo.html',
  '/': '/index.html'
};

// API handler registry
const API_ROUTES = {
  '/api/setup': require('./api/setup'),
  '/api/stats': require('./api/stats'),
  '/api/gallery': require('./api/gallery'),
  '/api/auth/login': require('./api/auth/login'),
  '/api/auth/logout': require('./api/auth/logout'),
  '/api/auth/me': require('./api/auth/me'),
  '/api/members': require('./api/members'),
  '/api/activities': require('./api/activities'),
  '/api/programs': require('./api/programs'),
  '/api/statistics': require('./api/statistics'),
  '/api/content': require('./api/content'),
  '/api/media': require('./api/media'),
  '/api/albums': require('./api/albums/index'),
  '/api/albums/manage': require('./api/albums/manage'),
  '/api/submissions': require('./api/submissions/index'),
  '/api/submissions/moderate': require('./api/submissions/moderate'),
  '/api/photos': require('./api/photos/index'),
  '/api/notifications': require('./api/notifications'),
  '/api/search': require('./api/search'),
  '/api/settings': require('./api/settings')
};

// Parse request body
function parseBody(req) {
  return new Promise((resolve) => {
    let chunks = [];
    req.on('data', chunk => chunks.push(chunk));
    req.on('end', () => {
      const buffer = Buffer.concat(chunks);
      req.rawBody = buffer;
      const str = buffer.toString('utf8');
      if (!str) return resolve({});
      try {
        resolve(JSON.parse(str));
      } catch (e) {
        resolve(str);
      }
    });
  });
}

// Create Vercel-compatible response wrapper
function enhanceResponse(res) {
  res.status = function (code) {
    this.statusCode = code;
    return this;
  };
  res.json = function (data) {
    this.setHeader('Content-Type', 'application/json');
    this.end(JSON.stringify(data));
    return this;
  };
  return res;
}

const server = http.createServer(async (req, res) => {
  const parsedUrl = new URL(req.url, 'http://' + (req.headers.host || 'localhost'));
  let pathname = parsedUrl.pathname;

  enhanceResponse(res);

  // Set default CORS
  res.setHeader('Access-Control-Allow-Origin', req.headers.origin || '*');
  res.setHeader('Access-Control-Allow-Credentials', 'true');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    res.statusCode = 200;
    return res.end();
  }

  // Handle API routes
  if (pathname.startsWith('/api/')) {
    const handler = API_ROUTES[pathname];
    if (handler) {
      req.query = Object.fromEntries(parsedUrl.searchParams);
      req.body = await parseBody(req);
      try {
        await handler(req, res);
      } catch (err) {
        console.error('API Error:', err);
        res.status(500).json({ success: false, error: 'Internal Server Error' });
      }
      return;
    } else {
      return res.status(404).json({ success: false, error: 'API route not found' });
    }
  }

  // Handle Clean URLs
  if (CLEAN_ROUTES[pathname]) {
    pathname = CLEAN_ROUTES[pathname];
  }

  // Handle Static Files
  let filePath = path.join(ROOT_DIR, pathname);
  
  // Security check: prevent directory traversal
  if (!filePath.startsWith(ROOT_DIR)) {
    res.statusCode = 403;
    return res.end('Forbidden');
  }

  fs.stat(filePath, (err, stats) => {
    if (err || !stats.isFile()) {
      // If .html extension is omitted, try finding it
      const htmlPath = filePath + '.html';
      if (fs.existsSync(htmlPath)) {
        filePath = htmlPath;
      } else {
        res.statusCode = 404;
        res.setHeader('Content-Type', 'text/html; charset=utf-8');
        return res.end('<h1>404 Not Found</h1><p>The requested page was not found on RC Sindhri server.</p>');
      }
    }

    const ext = path.extname(filePath).toLowerCase();
    const mimeType = MIME_TYPES[ext] || 'application/octet-stream';

    res.statusCode = 200;
    res.setHeader('Content-Type', mimeType);

    const stream = fs.createReadStream(filePath);
    stream.pipe(res);
  });
});

server.listen(PORT, () => {
  console.log(`\n======================================================`);
  console.log(`🚀 RC Sindhri Web & Admin Server Running!`);
  console.log(`📡 URL: http://localhost:${PORT}/`);
  console.log(`🛡️ Admin Portal: http://localhost:${PORT}/admin/login.html`);
  console.log(`======================================================\n`);
});
