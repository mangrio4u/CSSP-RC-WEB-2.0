// api/photos/index.js - Admin & Public Photo Listing and Uploads

const auth = require('../../lib/auth');
const db = require('../../lib/db');
const imgbb = require('../../lib/imgbb');

module.exports = async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Credentials', 'true');
  res.setHeader('Access-Control-Allow-Origin', req.headers.origin || '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  // GET: List photos
  if (req.method === 'GET') {
    try {
      const admin = auth.verifyAdmin(req);
      const { album_id, status, is_published } = req.query;

      const filters = {};
      if (album_id) filters.album_id = album_id;

      if (admin) {
        if (status) filters.status = status;
        if (is_published !== undefined) filters.is_published = is_published === 'true';
      } else {
        filters.status = 'approved';
        filters.is_published = true;
      }

      const photos = await db.getPhotos(filters);
      return res.status(200).json({ success: true, photos });
    } catch (error) {
      return res.status(500).json({ success: false, error: 'Failed to retrieve photos' });
    }
  }

  // POST: Direct Admin Photo Upload
  if (req.method === 'POST') {
    const admin = auth.verifyAdmin(req);
    if (!admin) {
      return res.status(401).json({ success: false, error: 'Unauthorized. Admin access required.' });
    }

    try {
      let body = req.body;
      if (typeof body === 'string') {
        try { body = JSON.parse(body); } catch (e) {}
      }

      const { title, description, location, album_id, imageBase64, imageUrl } = body || {};

      if (!title || !title.trim()) {
        return res.status(400).json({ success: false, error: 'Photo title is required' });
      }

      if (!imageBase64 && !imageUrl) {
        return res.status(400).json({ success: false, error: 'Image data or URL is required' });
      }

      let finalImageUrl = imageUrl;
      let finalThumbUrl = imageUrl;
      let finalDeleteUrl = null;

      const rawCandidate = imageBase64 || (imageUrl && imgbb.isBase64Image(imageUrl) ? imageUrl : null);
      if (rawCandidate) {
        const uploadResult = await imgbb.uploadImage(rawCandidate, title.trim());
        if (!uploadResult.success) {
          return res.status(502).json({ success: false, error: `ImgBB upload failed: ${uploadResult.error}` });
        }
        finalImageUrl = uploadResult.data.display_url || uploadResult.data.url;
        finalThumbUrl = (uploadResult.data.thumb && uploadResult.data.thumb.url) || finalImageUrl;
        finalDeleteUrl = uploadResult.data.delete_url || null;
      }

      if (!finalImageUrl || imgbb.isBase64Image(finalImageUrl)) {
        return res.status(400).json({ success: false, error: 'Valid hosted image URL is required. Base64 cannot be stored directly.' });
      }

      const newPhoto = await db.createPhotoSubmission({
        title: title.trim(),
        description: description ? description.trim() : '',
        location: location ? location.trim() : '',
        album_id: album_id || null,
        image_url: finalImageUrl,
        thumbnail_url: finalThumbUrl,
        delete_url: finalDeleteUrl,
        submitter_name: admin.name || 'RC Sindhri Admin',
        submitter_email: admin.email,
        status: 'approved',
        is_published: true,
        reviewed_at: new Date().toISOString(),
        reviewed_by: admin.email
      });

      return res.status(201).json({
        success: true,
        message: 'Photo uploaded and published successfully',
        photo: newPhoto
      });
    } catch (error) {
      console.error('Photo upload error:', error);
      return res.status(500).json({ success: false, error: 'Failed to upload photo' });
    }
  }

  return res.status(405).json({ success: false, error: 'Method Not Allowed' });
};
