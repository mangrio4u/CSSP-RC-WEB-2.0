// api/search.js - Global Search API for RC Sindhri Website Admin Panel
const auth = require('../lib/auth');
const db = require('../lib/db');

module.exports = async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Credentials', 'true');
  res.setHeader('Access-Control-Allow-Origin', req.headers.origin || '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') return res.status(200).end();

  const admin = auth.verifyAdmin(req);
  if (!admin) {
    return res.status(401).json({ success: false, error: 'Unauthorized' });
  }

  try {
    const { q } = req.query || {};
    if (!q || q.trim().length < 2) {
      return res.status(200).json({
        success: true,
        results: { members: [], activities: [], programs: [], albums: [], statistics: [] }
      });
    }

    const query = q.trim().toLowerCase();

    const members = await db.getAll('community_members');
    const activities = await db.getAll('activities');
    const programs = await db.getAll('projects');
    const albums = await db.getAll('albums');
    const stats = await db.getAll('impact_statistics');

    const matchedMembers = members.filter(m =>
      (m.full_name && m.full_name.toLowerCase().includes(query)) ||
      (m.designation_title && m.designation_title.toLowerCase().includes(query)) ||
      (m.committee_type && m.committee_type.toLowerCase().includes(query))
    ).slice(0, 5);

    const matchedActivities = activities.filter(a =>
      (a.title && a.title.toLowerCase().includes(query)) ||
      (a.activity_type && a.activity_type.toLowerCase().includes(query)) ||
      (a.location && a.location.toLowerCase().includes(query))
    ).slice(0, 5);

    const matchedPrograms = programs.filter(p =>
      (p.name && p.name.toLowerCase().includes(query)) ||
      (p.short_name && p.short_name.toLowerCase().includes(query)) ||
      (p.description && p.description.toLowerCase().includes(query))
    ).slice(0, 5);

    const matchedAlbums = albums.filter(al =>
      (al.title && al.title.toLowerCase().includes(query)) ||
      (al.slug && al.slug.toLowerCase().includes(query)) ||
      (al.description && al.description.toLowerCase().includes(query))
    ).slice(0, 5);

    const matchedStats = stats.filter(s =>
      (s.label && s.label.toLowerCase().includes(query)) ||
      (s.stat_key && s.stat_key.toLowerCase().includes(query)) ||
      (s.display_value && s.display_value.toLowerCase().includes(query))
    ).slice(0, 5);

    return res.status(200).json({
      success: true,
      results: {
        members: matchedMembers,
        activities: matchedActivities,
        programs: matchedPrograms,
        albums: matchedAlbums,
        statistics: matchedStats
      }
    });
  } catch (error) {
    console.error('Search API Error:', error);
    return res.status(500).json({ success: false, error: 'Search execution failed' });
  }
};
