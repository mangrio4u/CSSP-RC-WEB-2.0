// api/auth/logout.js - Admin Logout Endpoint

const auth = require('../../lib/auth');

module.exports = async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Credentials', 'true');
  res.setHeader('Access-Control-Allow-Origin', req.headers.origin || '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  // Clear HTTP-Only Cookie
  res.setHeader('Set-Cookie', auth.createClearCookie());

  return res.status(200).json({
    success: true,
    message: 'Logged out successfully'
  });
};
