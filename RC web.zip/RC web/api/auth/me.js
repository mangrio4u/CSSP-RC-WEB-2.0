// api/auth/me.js - Admin Session Verification Endpoint

const auth = require('../../lib/auth');

module.exports = async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Credentials', 'true');
  res.setHeader('Access-Control-Allow-Origin', req.headers.origin || '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  const admin = auth.verifyAdmin(req);
  if (!admin) {
    return res.status(401).json({ success: false, authenticated: false, error: 'Unauthorized session' });
  }

  return res.status(200).json({
    success: true,
    authenticated: true,
    user: {
      email: admin.email,
      name: admin.name || 'Administrator',
      role: admin.role || 'admin'
    }
  });
};
