// api/programs.js - RC Sindhri Programs & Projects Management API
const auth = require('../lib/auth');
const db = require('../lib/db');

module.exports = async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Credentials', 'true');
  res.setHeader('Access-Control-Allow-Origin', req.headers.origin || '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') return res.status(200).end();

  const isPublicGet = req.method === 'GET' && req.query && (req.query.public === 'true' || !req.headers.authorization);

  if (!isPublicGet) {
    const admin = auth.verifyAdmin(req);
    if (!admin) {
      return res.status(401).json({ success: false, error: 'Unauthorized. Admin login required.' });
    }
  }

  try {
    if (req.method === 'GET') {
      const { id, status, search } = req.query || {};

      if (id) {
        const prog = await db.getById('projects', id);
        if (!prog) return res.status(404).json({ success: false, error: 'Program not found' });
        return res.status(200).json({ success: true, program: prog });
      }

      let programs = await db.getAll('projects', {}, { orderBy: 'display_order', ascending: true });

      if (isPublicGet) {
        programs = programs.filter(p => p.is_published !== false);
      } else if (status && status !== 'all') {
        programs = programs.filter(p => (p.status || '').toLowerCase() === status.toLowerCase());
      }

      if (search) {
        const s = search.toLowerCase();
        programs = programs.filter(p =>
          (p.name && p.name.toLowerCase().includes(s)) ||
          (p.short_name && p.short_name.toLowerCase().includes(s)) ||
          (p.project_type && p.project_type.toLowerCase().includes(s)) ||
          (p.description && p.description.toLowerCase().includes(s))
        );
      }

      programs.sort((a, b) => (Number(a.display_order) || 99) - (Number(b.display_order) || 99));

      return res.status(200).json({
        success: true,
        count: programs.length,
        programs
      });
    }

    if (req.method === 'POST') {
      const body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
      const {
        name, short_name, description, project_type,
        start_date, end_date, status, location, partner,
        funding_info, objectives, achievements, impact,
        project_image_url, project_manager, display_order, is_published
      } = body;

      if (!name) {
        return res.status(400).json({ success: false, error: 'Program name is required.' });
      }

      const generatedShort = (short_name || name.split(' ').map(w => w[0]).join('')).toUpperCase().slice(0, 10);

      const record = await db.create('projects', {
        name: name.trim(),
        short_name: generatedShort,
        description: description || '',
        project_type: project_type || 'Youth & Community Development',
        start_date: start_date || '2023-01-01',
        end_date: end_date || '2026-12-31',
        status: status || 'Active',
        location: location || 'UC Sindhri, Mirpur Khas',
        partner: partner || 'RC Sindhri Initiative',
        funding_info: funding_info || '',
        objectives: objectives || '',
        achievements: achievements || '',
        impact: impact || '',
        project_image_url: project_image_url || 'https://images.unsplash.com/photo-1529156069898-49953e39b3ac?w=800',
        project_manager: project_manager || 'RC Sindhri Focal Team',
        display_order: parseInt(display_order) || 1,
        is_published: is_published !== false
      });

      return res.status(201).json({ success: true, message: 'Program created successfully', program: record });
    }

    if (req.method === 'PUT') {
      const { id } = req.query || {};
      const body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
      const targetId = id || body.id;

      if (!targetId) return res.status(400).json({ success: false, error: 'Program ID is required' });

      const updated = await db.update('projects', targetId, body);
      if (!updated) return res.status(404).json({ success: false, error: 'Program not found' });

      return res.status(200).json({ success: true, message: 'Program updated successfully', program: updated });
    }

    if (req.method === 'DELETE') {
      const { id } = req.query || {};
      if (!id) return res.status(400).json({ success: false, error: 'Program ID is required' });

      await db.delete('projects', id);
      return res.status(200).json({ success: true, message: 'Program deleted successfully' });
    }

    return res.status(405).json({ success: false, error: 'Method not allowed' });
  } catch (error) {
    console.error('Programs API Error:', error);
    return res.status(500).json({ success: false, error: 'Internal server error processing program' });
  }
};
