// api/reports.js - Reports & Analytics API for RC Sindhri
const auth = require('../lib/auth');
const db = require('../lib/db');

module.exports = async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Credentials', 'true');
  res.setHeader('Access-Control-Allow-Origin', req.headers.origin || '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') return res.status(200).end();

  const admin = auth.verifyAdmin(req);
  if (!admin) {
    return res.status(401).json({ success: false, error: 'Unauthorized. Admin access required.' });
  }

  try {
    const { range = 'all', format } = req.query || {};

    const candidates = await this_getAll('candidates');
    const jobs = await this_getAll('jobs');
    const employers = await this_getAll('employers');
    const applications = await this_getAll('applications');

    // Aggregate statistics
    const totalCandidates = candidates.length;
    const totalEmployers = employers.length;
    const totalJobs = jobs.length;
    const activeJobs = jobs.filter(j => j.status === 'Active').length;
    const expiredJobs = jobs.filter(j => j.status === 'Expired').length;
    const totalApplications = applications.length;
    const hiredCandidates = applications.filter(a => a.status === 'Selected').length;
    const rejectedApplications = applications.filter(a => a.status === 'Rejected').length;

    // Jobs by category
    const jobsByCategory = {};
    jobs.forEach(j => {
      const c = j.category || 'Others';
      jobsByCategory[c] = (jobsByCategory[c] || 0) + 1;
    });

    // Jobs by employer
    const jobsByEmployer = {};
    jobs.forEach(j => {
      const emp = j.employer_name || 'Partner Employer';
      jobsByEmployer[emp] = (jobsByEmployer[emp] || 0) + 1;
    });

    // Applications by status
    const appsByStatus = {};
    applications.forEach(a => {
      appsByStatus[a.status] = (appsByStatus[a.status] || 0) + 1;
    });

    // Candidates by gender
    const candidatesByGender = {
      Male: candidates.filter(c => c.gender === 'Male').length,
      Female: candidates.filter(c => c.gender === 'Female').length,
      Other: candidates.filter(c => c.gender === 'Other').length
    };

    // Candidates by trade/skill
    const candidatesByTrade = {};
    candidates.forEach(c => {
      const t = c.trade_name || 'General';
      candidatesByTrade[t] = (candidatesByTrade[t] || 0) + 1;
    });

    // If format is CSV, generate CSV file string
    if (format === 'csv') {
      res.setHeader('Content-Type', 'text/csv');
      res.setHeader('Content-Disposition', 'attachment; filename="rc_sindhri_recruitment_report.csv"');

      let csv = 'Report,Category,Metric,Value\n';
      csv += `Overview,Candidates,Total Candidates,${totalCandidates}\n`;
      csv += `Overview,Employers,Total Employers,${totalEmployers}\n`;
      csv += `Overview,Jobs,Total Jobs,${totalJobs}\n`;
      csv += `Overview,Jobs,Active Jobs,${activeJobs}\n`;
      csv += `Overview,Applications,Total Applications,${totalApplications}\n`;
      csv += `Overview,Placements,Hired Candidates,${hiredCandidates}\n`;
      csv += `Overview,Placements,Rejected Applications,${rejectedApplications}\n`;

      Object.entries(jobsByCategory).forEach(([k, v]) => {
        csv += `Jobs By Category,${k},Count,${v}\n`;
      });
      Object.entries(appsByStatus).forEach(([k, v]) => {
        csv += `Applications By Status,${k},Count,${v}\n`;
      });

      return res.status(200).send(csv);
    }

    return res.status(200).json({
      success: true,
      report: {
        range,
        overview: {
          total_candidates: totalCandidates,
          total_employers: totalEmployers,
          total_jobs: totalJobs,
          active_jobs: activeJobs,
          expired_jobs: expiredJobs,
          total_applications: totalApplications,
          hired_candidates: hiredCandidates,
          rejected_applications: rejectedApplications
        },
        jobs_analytics: {
          by_category: jobsByCategory,
          by_employer: jobsByEmployer
        },
        application_analytics: {
          by_status: appsByStatus
        },
        candidate_analytics: {
          by_gender: candidatesByGender,
          by_trade: candidatesByTrade
        }
      }
    });
  } catch (error) {
    console.error('Reports API Error:', error);
    return res.status(500).json({ success: false, error: 'Internal server error generating report' });
  }

  async function this_getAll(table) {
    return await db.getAll(table);
  }
};
