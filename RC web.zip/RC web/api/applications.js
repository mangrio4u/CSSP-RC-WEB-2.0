// api/applications.js - Applications Management API for RC Sindhri
const auth = require('../lib/auth');
const db = require('../lib/db');

module.exports = async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Credentials', 'true');
  res.setHeader('Access-Control-Allow-Origin', req.headers.origin || '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') return res.status(200).end();

  // Public candidate can POST an application
  if (req.method === 'POST') {
    try {
      const body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
      const {
        job_id, candidate_name, candidate_email, candidate_phone,
        cover_letter, resume_url
      } = body;

      if (!job_id || !candidate_name) {
        return res.status(400).json({ success: false, error: 'Job and candidate name are required.' });
      }

      const job = await db.getById('jobs', job_id);
      if (!job) return res.status(404).json({ success: false, error: 'Target job not found.' });

      // Find or create candidate profile
      let candidates = await db.getAll('candidates');
      let candidate = candidates.find(c => c.email && c.email.toLowerCase() === (candidate_email || '').toLowerCase());
      if (!candidate) {
        candidate = await db.create('candidates', {
          full_name: candidate_name.trim(),
          email: candidate_email ? candidate_email.trim() : null,
          phone: candidate_phone || '',
          resume_url: resume_url || '',
          location: 'Sindhri',
          account_status: 'Active'
        });
      }

      const newApp = await db.create('applications', {
        job_id: job.id,
        job_title: job.title,
        candidate_id: candidate.id,
        candidate_name: candidate.full_name,
        candidate_email: candidate.email,
        candidate_phone: candidate.phone,
        employer_id: job.employer_id,
        employer_name: job.employer_name,
        status: 'Pending',
        cover_letter: cover_letter || '',
        notes: '',
        applied_on: new Date().toISOString().split('T')[0]
      });

      // Create notification & activity
      await db.create('notifications', {
        title: 'New Application Received',
        message: `${newApp.candidate_name} applied for ${newApp.job_title} at ${newApp.employer_name}`,
        type: 'application',
        entity_id: newApp.id,
        is_read: false
      });

      await db.create('activity_logs', {
        type: 'Application',
        title: 'New Application Received',
        description: `${newApp.candidate_name} applied for ${newApp.job_title}`,
        user_email: candidate_email || 'visitor'
      });

      return res.status(201).json({ success: true, message: 'Application submitted successfully', application: newApp });
    } catch (err) {
      console.error('Submit application error:', err);
      return res.status(500).json({ success: false, error: 'Failed to submit application' });
    }
  }

  // All other application routes require admin authorization
  const admin = auth.verifyAdmin(req);
  if (!admin) {
    return res.status(401).json({ success: false, error: 'Unauthorized. Admin access required.' });
  }

  try {
    if (req.method === 'GET') {
      const { id, search, status, job_id, candidate_id, employer_id, limit = 50, page = 1 } = req.query || {};

      if (id) {
        const app = await db.getById('applications', id);
        if (!app) return res.status(404).json({ success: false, error: 'Application not found' });
        return res.status(200).json({ success: true, application: app });
      }

      let applications = await db.getAll('applications', {}, { orderBy: 'created_at', ascending: false });

      if (status && status !== 'all') {
        applications = applications.filter(a => a.status.toLowerCase() === status.toLowerCase());
      }
      if (job_id) {
        applications = applications.filter(a => a.job_id === job_id);
      }
      if (candidate_id) {
        applications = applications.filter(a => a.candidate_id === candidate_id);
      }
      if (employer_id) {
        applications = applications.filter(a => a.employer_id === employer_id);
      }
      if (search) {
        const s = search.toLowerCase();
        applications = applications.filter(a =>
          (a.candidate_name && a.candidate_name.toLowerCase().includes(s)) ||
          (a.job_title && a.job_title.toLowerCase().includes(s)) ||
          (a.employer_name && a.employer_name.toLowerCase().includes(s))
        );
      }

      const total = applications.length;
      const startIndex = (parseInt(page) - 1) * parseInt(limit);
      const paginated = applications.slice(startIndex, startIndex + parseInt(limit));

      return res.status(200).json({
        success: true,
        applications: paginated,
        pagination: { total, page: parseInt(page), limit: parseInt(limit), totalPages: Math.ceil(total / parseInt(limit)) }
      });
    }

    if (req.method === 'PUT') {
      const { id } = req.query || {};
      const body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
      const targetId = id || body.id;

      if (!targetId) return res.status(400).json({ success: false, error: 'Application ID required' });

      const existing = await db.getById('applications', targetId);
      if (!existing) return res.status(404).json({ success: false, error: 'Application not found' });

      const updated = await db.update('applications', targetId, body);

      // Log status change if status changed
      if (body.status && body.status !== existing.status) {
        await db.create('activity_logs', {
          type: 'Status Change',
          title: 'Candidate Status Updated',
          description: `${existing.candidate_name} → ${body.status}`,
          user_email: admin.email
        });
      }

      return res.status(200).json({ success: true, message: 'Application updated successfully', application: updated });
    }

    if (req.method === 'DELETE') {
      const { id } = req.query || {};
      if (!id) return res.status(400).json({ success: false, error: 'Application ID required' });

      await db.delete('applications', id);
      return res.status(200).json({ success: true, message: 'Application deleted successfully' });
    }

    return res.status(405).json({ success: false, error: 'Method not allowed' });
  } catch (error) {
    console.error('Applications API Error:', error);
    return res.status(500).json({ success: false, error: 'Internal server error processing application request' });
  }
};
