// api/gallery.js - Public Gallery Data API

const db = require('../lib/db');

module.exports = async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'GET') {
    return res.status(405).json({ success: false, error: 'Method Not Allowed' });
  }

  try {
    const { album } = req.query;

    // Fetch visible albums
    const albums = await db.getAlbums(true);

    // Fetch approved, published photos
    const filter = {
      status: 'approved',
      is_published: true
    };

    if (album && album !== 'all') {
      const matchedAlbum = albums.find(a => a.slug === album || a.id === album);
      if (matchedAlbum) {
        filter.album_id = matchedAlbum.id;
      }
    }

    const photos = await db.getPhotos(filter);

    return res.status(200).json({
      success: true,
      albums,
      photos
    });
  } catch (error) {
    console.error('Gallery API error:', error);
    return res.status(500).json({ success: false, error: 'Failed to load gallery' });
  }
};
