// api/media.js - RC Sindhri Media & Image Hosting API with ImgBB
const auth = require('../lib/auth');
const db = require('../lib/db');
const imgbb = require('../lib/imgbb');

// Helper to extract a file buffer and field values from multipart/form-data
function parseMultipartBuffer(rawBuffer, contentType) {
  if (!rawBuffer || !contentType) return null;
  const match = contentType.match(/boundary=(?:"([^"]+)"|([^;]+))/i);
  if (!match) return null;
  const boundary = match[1] || match[2];
  const boundaryBuf = Buffer.from('--' + boundary);

  let searchIndex = 0;
  let fileBuffer = null;
  let fileName = 'upload.jpg';
  const fields = {};

  while (true) {
    const boundaryIdx = rawBuffer.indexOf(boundaryBuf, searchIndex);
    if (boundaryIdx === -1) break;

    const nextBoundaryIdx = rawBuffer.indexOf(boundaryBuf, boundaryIdx + boundaryBuf.length);
    if (nextBoundaryIdx === -1) break;

    const part = rawBuffer.subarray(boundaryIdx + boundaryBuf.length, nextBoundaryIdx);
    searchIndex = nextBoundaryIdx;

    const headerEndIdx = part.indexOf(Buffer.from('\r\n\r\n'));
    if (headerEndIdx === -1) continue;

    const headerStr = part.subarray(0, headerEndIdx).toString('utf8');
    // Content is between headerEndIdx + 4 and end minus trailing \r\n (2 bytes)
    const dataStart = headerEndIdx + 4;
    const dataEnd = part.length >= 2 && part[part.length - 2] === 13 && part[part.length - 1] === 10
      ? part.length - 2
      : part.length;

    const partData = part.subarray(dataStart, dataEnd);

    const nameMatch = headerStr.match(/name="([^"]+)"/i);
    const filenameMatch = headerStr.match(/filename="([^"]+)"/i);

    if (filenameMatch) {
      fileName = filenameMatch[1];
      fileBuffer = partData;
    } else if (nameMatch) {
      fields[nameMatch[1]] = partData.toString('utf8');
    }
  }

  return { fileBuffer, fileName, fields };
}

module.exports = async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Credentials', 'true');
  res.setHeader('Access-Control-Allow-Origin', req.headers.origin || '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') return res.status(200).end();

  const isPublicGet = req.method === 'GET' && req.query && (req.query.public === 'true' || !req.headers.authorization);

  if (!isPublicGet) {
    const admin = auth.verifyAdmin(req);
    if (!admin) {
      return res.status(401).json({ success: false, error: 'Unauthorized. Admin login required.' });
    }
  }

  try {
    // ----------------------------------------------------
    // GET: List media library photos & albums
    // ----------------------------------------------------
    if (req.method === 'GET') {
      const { album_id, search, limit } = req.query || {};

      let photos = await db.getPhotos();
      const albums = await db.getAlbums();

      if (album_id && album_id !== 'all') {
        photos = photos.filter(p => p.album_id === album_id);
      }

      if (search) {
        const s = search.toLowerCase();
        photos = photos.filter(p =>
          (p.title && p.title.toLowerCase().includes(s)) ||
          (p.description && p.description.toLowerCase().includes(s)) ||
          (p.location && p.location.toLowerCase().includes(s))
        );
      }

      if (limit) {
        photos = photos.slice(0, parseInt(limit));
      }

      return res.status(200).json({
        success: true,
        total: photos.length,
        photos,
        albums
      });
    }

    // ----------------------------------------------------
    // POST: Upload image to ImgBB and optionally save photo
    // ----------------------------------------------------
    if (req.method === 'POST') {
      const cType = (req.headers['content-type'] || '').toLowerCase();
      let fileBuffer = null;
      let rawBase64 = null;
      let photoTitle = '';
      let albumId = null;
      let description = '';
      let location = 'UC Sindhri, Mirpur Khas';
      let imageUrl = null;

      // Check for multipart/form-data upload
      if (cType.includes('multipart/form-data')) {
        const parsed = parseMultipartBuffer(req.rawBody, req.headers['content-type']);
        if (parsed) {
          fileBuffer = parsed.fileBuffer;
          photoTitle = parsed.fields.title || parsed.fileName || 'rc_media_photo';
          albumId = parsed.fields.album_id || null;
          description = parsed.fields.description || '';
          location = parsed.fields.location || location;
        }
      } else {
        // Standard JSON body
        let body = req.body;
        if (typeof body === 'string') {
          try { body = JSON.parse(body); } catch (e) {}
        }
        if (body && typeof body === 'object') {
          photoTitle = (body.title || body.name || '').trim();
          albumId = body.album_id || null;
          description = (body.description || '').trim();
          location = (body.location || location).trim();
          imageUrl = body.image_url || body.imageUrl || null;

          if (body.imageBase64 || body.fileBase64 || body.file) {
            rawBase64 = body.imageBase64 || body.fileBase64 || body.file;
          } else if (imageUrl && imgbb.isBase64Image(imageUrl)) {
            rawBase64 = imageUrl;
          }
        }
      }

      // If an image file/base64 was submitted, upload to ImgBB
      let hostedUrl = null;
      let thumbUrl = null;
      let deleteUrl = null;

      if (fileBuffer && fileBuffer.length > 0) {
        const uploadResult = await imgbb.uploadImage(fileBuffer, photoTitle || 'rc_sindhri_photo');
        if (!uploadResult.success) {
          return res.status(502).json({ success: false, error: `ImgBB upload failed: ${uploadResult.error}` });
        }
        hostedUrl = uploadResult.data.display_url || uploadResult.data.url;
        thumbUrl = (uploadResult.data.thumb && uploadResult.data.thumb.url) || hostedUrl;
        deleteUrl = uploadResult.data.delete_url || null;
      } else if (rawBase64) {
        const uploadResult = await imgbb.uploadImage(rawBase64, photoTitle || 'rc_sindhri_photo');
        if (!uploadResult.success) {
          return res.status(502).json({ success: false, error: `ImgBB upload failed: ${uploadResult.error}` });
        }
        hostedUrl = uploadResult.data.display_url || uploadResult.data.url;
        thumbUrl = (uploadResult.data.thumb && uploadResult.data.thumb.url) || hostedUrl;
        deleteUrl = uploadResult.data.delete_url || null;
      } else if (imageUrl && !imgbb.isBase64Image(imageUrl)) {
        // It is already a remote HTTP URL
        hostedUrl = imageUrl.trim();
        thumbUrl = imageUrl.trim();
      }

      if (!hostedUrl) {
        return res.status(400).json({ success: false, error: 'No valid image file or URL provided' });
      }

      // If photoTitle is provided, create photo record in database
      if (photoTitle) {
        const photo = await db.createPhoto({
          title: photoTitle,
          image_url: hostedUrl,
          thumbnail_url: thumbUrl,
          delete_url: deleteUrl,
          album_id: albumId || null,
          description: description,
          location: location,
          status: 'approved',
          is_published: true,
          consent_given: true,
          submitter_name: 'RC Sindhri Admin'
        });

        return res.status(201).json({
          success: true,
          message: 'Media photo uploaded to ImgBB and saved successfully',
          url: hostedUrl,
          display_url: hostedUrl,
          thumbnail_url: thumbUrl,
          delete_url: deleteUrl,
          photo
        });
      }

      // Otherwise return hosted URL for usage across CMS/covers/members
      return res.status(200).json({
        success: true,
        message: 'Image hosted on ImgBB successfully',
        url: hostedUrl,
        display_url: hostedUrl,
        thumbnail_url: thumbUrl,
        delete_url: deleteUrl
      });
    }

    // ----------------------------------------------------
    // PUT: Update media item
    // ----------------------------------------------------
    if (req.method === 'PUT') {
      const { id } = req.query || {};
      const body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
      const targetId = id || body.id;

      if (!targetId) return res.status(400).json({ success: false, error: 'Photo ID is required' });

      // If updated image_url contains base64, sanitizeAndHostImages inside db.update will auto-upload
      const updated = await db.updatePhoto(targetId, body);
      if (!updated) return res.status(404).json({ success: false, error: 'Photo not found' });

      return res.status(200).json({ success: true, message: 'Media updated successfully', photo: updated });
    }

    // ----------------------------------------------------
    // DELETE: Delete media item
    // ----------------------------------------------------
    if (req.method === 'DELETE') {
      const { id } = req.query || {};
      if (!id) return res.status(400).json({ success: false, error: 'Photo ID is required' });

      await db.deletePhoto(id);
      return res.status(200).json({ success: true, message: 'Media deleted successfully' });
    }

    return res.status(405).json({ success: false, error: 'Method not allowed' });
  } catch (error) {
    console.error('Media API Error:', error);
    return res.status(500).json({ success: false, error: 'Failed to process media request: ' + error.message });
  }
};
