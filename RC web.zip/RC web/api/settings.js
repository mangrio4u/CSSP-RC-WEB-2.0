// api/settings.js - RC Sindhri Site Settings & Branding API
const auth = require('../lib/auth');
const db = require('../lib/db');

module.exports = async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Credentials', 'true');
  res.setHeader('Access-Control-Allow-Origin', req.headers.origin || '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') return res.status(200).end();

  const isPublicGet = req.method === 'GET' && req.query && (req.query.public === 'true' || !req.headers.authorization);

  if (req.method === 'GET') {
    try {
      const settingsList = await db.getAll('site_settings');
      const settingsMap = {};
      settingsList.forEach(s => {
        settingsMap[s.setting_key] = s.setting_value;
      });

      return res.status(200).json({
        success: true,
        settings: settingsMap,
        raw_list: settingsList
      });
    } catch (err) {
      console.error('Settings fetch error:', err);
      return res.status(500).json({ success: false, error: 'Failed to fetch settings' });
    }
  }

  // Modifying settings requires admin verification
  const admin = auth.verifyAdmin(req);
  if (!admin) {
    return res.status(401).json({ success: false, error: 'Unauthorized. Admin login required.' });
  }

  try {
    if (req.method === 'POST' || req.method === 'PUT') {
      const body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;

      // Handle batch settings updates: { settings: { key1: val1, key2: val2 } }
      if (body.settings && typeof body.settings === 'object') {
        const results = {};
        for (const [key, val] of Object.entries(body.settings)) {
          if (!key) continue;
          const strVal = String(val !== undefined && val !== null ? val : '');
          const existing = await db.getById('site_settings', key);
          if (existing) {
            await db.update('site_settings', key, { setting_value: strVal, updated_at: new Date().toISOString() });
          } else {
            await db.create('site_settings', { setting_key: key, setting_value: strVal, updated_at: new Date().toISOString() });
          }
          results[key] = strVal;
        }
        return res.status(200).json({ success: true, message: 'Settings saved successfully', settings: results });
      }

      // Single setting update: { setting_key, setting_value, description }
      const { setting_key, setting_value, description } = body;
      if (!setting_key) {
        return res.status(400).json({ success: false, error: 'setting_key is required' });
      }

      const strVal = String(setting_value !== undefined && setting_value !== null ? setting_value : '');
      const existing = await db.getById('site_settings', setting_key);
      let saved;
      if (existing) {
        saved = await db.update('site_settings', setting_key, {
          setting_value: strVal,
          description: description !== undefined ? description : existing.description,
          updated_at: new Date().toISOString()
        });
      } else {
        saved = await db.create('site_settings', {
          setting_key,
          setting_value: strVal,
          description: description || '',
          updated_at: new Date().toISOString()
        });
      }

      return res.status(200).json({ success: true, message: 'Setting saved successfully', setting: saved });
    }

    if (req.method === 'DELETE') {
      const { key, id } = req.query || {};
      const target = key || id;
      if (!target) return res.status(400).json({ success: false, error: 'key or id is required' });

      await db.delete('site_settings', target);
      return res.status(200).json({ success: true, message: `Setting "${target}" deleted successfully` });
    }

    return res.status(405).json({ success: false, error: 'Method not allowed' });
  } catch (err) {
    console.error('Settings save error:', err);
    return res.status(500).json({ success: false, error: 'Failed to update settings' });
  }
};
