// api/setup.js - Health & Integration Status

const auth = require('../lib/auth');
const db = require('../lib/db');
const imgbb = require('../lib/imgbb');

module.exports = async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,OPTIONS');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  const supabaseConnected = db.isSupabaseConfigured();
  const imgbbConfigured = !!imgbb.getApiKey();
  const adminEmailConfigured = !!process.env.ADMIN_EMAIL;
  const jwtConfigured = !!process.env.ADMIN_JWT_SECRET;

  return res.status(200).json({
    success: true,
    status: 'operational',
    timestamp: new Date().toISOString(),
    integrations: {
      database: {
        type: supabaseConnected ? 'Supabase (PostgreSQL)' : 'Local File Store (Development/Fallback)',
        configured: supabaseConnected,
        tableReady: true
      },
      imgbb: {
        configured: imgbbConfigured,
        message: imgbbConfigured ? 'ImgBB API key is active' : 'IMGBB_API_KEY environment variable is not configured yet. Set IMGBB_API_KEY for live hosting.'
      },
      auth: {
        jwtSecretSet: jwtConfigured,
        customAdminEmail: adminEmailConfigured
      }
    }
  });
};
