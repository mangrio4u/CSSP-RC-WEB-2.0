// api/members.js - RC Management Committee, Manzil, and PTY Members API
const auth = require('../lib/auth');
const db = require('../lib/db');

module.exports = async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Credentials', 'true');
  res.setHeader('Access-Control-Allow-Origin', req.headers.origin || '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') return res.status(200).end();

  const isPublicGet = req.method === 'GET' && req.query && (req.query.public === 'true' || !req.headers.authorization);

  if (!isPublicGet) {
    const admin = auth.verifyAdmin(req);
    if (!admin) {
      return res.status(401).json({ success: false, error: 'Unauthorized. Admin login required.' });
    }
  }

  try {
    if (req.method === 'GET') {
      const { id, committee_type, status, search } = req.query || {};

      if (id) {
        const member = await db.getById('community_members', id);
        if (!member) return res.status(404).json({ success: false, error: 'Member not found' });
        return res.status(200).json({ success: true, member });
      }

      let members = await db.getAll('community_members', {}, { orderBy: 'display_order', ascending: true });

      if (committee_type && committee_type !== 'all') {
        members = members.filter(m => (m.committee_type || 'management').toLowerCase() === committee_type.toLowerCase());
      }

      if (isPublicGet) {
        members = members.filter(m => m.status === 'Active' && m.is_public !== false);
      } else if (status && status !== 'all') {
        members = members.filter(m => m.status.toLowerCase() === status.toLowerCase());
      }

      if (search) {
        const s = search.toLowerCase();
        members = members.filter(m =>
          (m.full_name && m.full_name.toLowerCase().includes(s)) ||
          (m.designation_title && m.designation_title.toLowerCase().includes(s)) ||
          (m.department_area && m.department_area.toLowerCase().includes(s)) ||
          (m.village_name && m.village_name.toLowerCase().includes(s))
        );
      }

      // Sort by display_order
      members.sort((a, b) => (Number(a.display_order) || 99) - (Number(b.display_order) || 99));

      return res.status(200).json({
        success: true,
        members
      });
    }

    if (req.method === 'POST') {
      const body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
      const {
        full_name, designation_title, department_area, committee_type,
        mobile_number, email, village_name, education, skills,
        short_bio, profile_image_url, display_order, status
      } = body;

      if (!full_name || !designation_title) {
        return res.status(400).json({ success: false, error: 'Full name and designation are required.' });
      }

      const newMember = await db.create('community_members', {
        full_name: full_name.trim(),
        designation_title: designation_title.trim(),
        department_area: department_area || '',
        committee_type: committee_type || 'management',
        mobile_number: mobile_number || '',
        email: email || '',
        village_name: village_name || 'Village Haji Hamer Mangrio',
        education: education || '',
        skills: skills || '',
        short_bio: short_bio || '',
        profile_image_url: profile_image_url || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400',
        display_order: parseInt(display_order) || 10,
        status: status || 'Active',
        is_public: true
      });

      await db.create('activity_logs', {
        type: 'Member',
        title: 'New Member Added',
        description: `${newMember.full_name} (${newMember.designation_title}) added to ${newMember.committee_type.toUpperCase()}`,
        user_email: req.admin?.email || 'admin@rcsindhri.org'
      });

      return res.status(201).json({ success: true, message: 'Member created successfully', member: newMember });
    }

    if (req.method === 'PUT') {
      const { id } = req.query || {};
      const body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
      const targetId = id || body.id;

      if (!targetId) return res.status(400).json({ success: false, error: 'Member ID required' });

      const updated = await db.update('community_members', targetId, body);
      if (!updated) return res.status(404).json({ success: false, error: 'Member not found' });

      return res.status(200).json({ success: true, message: 'Member updated successfully', member: updated });
    }

    if (req.method === 'DELETE') {
      const { id } = req.query || {};
      if (!id) return res.status(400).json({ success: false, error: 'Member ID required' });

      await db.delete('community_members', id);
      return res.status(200).json({ success: true, message: 'Member deleted successfully' });
    }

    return res.status(405).json({ success: false, error: 'Method not allowed' });
  } catch (error) {
    console.error('Members API Error:', error);
    return res.status(500).json({ success: false, error: 'Internal server error processing members' });
  }
};
