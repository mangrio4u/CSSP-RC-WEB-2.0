// api/employers.js - Employers Management API for RC Sindhri
const auth = require('../lib/auth');
const db = require('../lib/db');

module.exports = async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Credentials', 'true');
  res.setHeader('Access-Control-Allow-Origin', req.headers.origin || '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') return res.status(200).end();

  const admin = auth.verifyAdmin(req);
  if (!admin) {
    return res.status(401).json({ success: false, error: 'Unauthorized. Admin access required.' });
  }

  try {
    if (req.method === 'GET') {
      const { id, search, industry, verification_status, status, limit = 50, page = 1 } = req.query || {};

      if (id) {
        const employer = await db.getById('employers', id);
        if (!employer) return res.status(404).json({ success: false, error: 'Employer not found' });

        // Retrieve jobs and applications related to this employer
        const jobs = await db.getAll('jobs', { employer_id: id });
        const applications = await db.getAll('applications', { employer_id: id });
        return res.status(200).json({ success: true, employer, jobs, applications });
      }

      let employers = await db.getAll('employers', {}, { orderBy: 'created_at', ascending: false });

      if (industry && industry !== 'all') {
        employers = employers.filter(e => e.industry && e.industry.toLowerCase() === industry.toLowerCase());
      }
      if (verification_status && verification_status !== 'all') {
        employers = employers.filter(e => e.verification_status && e.verification_status.toLowerCase() === verification_status.toLowerCase());
      }
      if (status && status !== 'all') {
        employers = employers.filter(e => e.status && e.status.toLowerCase() === status.toLowerCase());
      }
      if (search) {
        const s = search.toLowerCase();
        employers = employers.filter(e =>
          (e.company_name && e.company_name.toLowerCase().includes(s)) ||
          (e.contact_person && e.contact_person.toLowerCase().includes(s)) ||
          (e.email && e.email.toLowerCase().includes(s)) ||
          (e.phone && e.phone.includes(s)) ||
          (e.location && e.location.toLowerCase().includes(s))
        );
      }

      // Add jobs_count and applications_count to each employer
      const allJobs = await db.getAll('jobs');
      const allApps = await db.getAll('applications');

      const enrichedEmployers = employers.map(e => ({
        ...e,
        jobs_count: allJobs.filter(j => j.employer_id === e.id).length,
        applications_count: allApps.filter(a => a.employer_id === e.id).length
      }));

      const total = enrichedEmployers.length;
      const startIndex = (parseInt(page) - 1) * parseInt(limit);
      const paginated = enrichedEmployers.slice(startIndex, startIndex + parseInt(limit));

      return res.status(200).json({
        success: true,
        employers: paginated,
        pagination: { total, page: parseInt(page), limit: parseInt(limit), totalPages: Math.ceil(total / parseInt(limit)) }
      });
    }

    if (req.method === 'POST') {
      const body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
      const { company_name, industry, contact_person, email, phone, location, address, website, description, verification_status } = body;

      if (!company_name) {
        return res.status(400).json({ success: false, error: 'Company name is required.' });
      }

      const newEmployer = await db.create('employers', {
        company_name: company_name.trim(),
        industry: industry || 'General',
        contact_person: contact_person || '',
        email: email ? email.trim() : null,
        phone: phone ? phone.trim() : null,
        location: location || 'Sindhri',
        address: address || '',
        website: website || '',
        verification_status: verification_status || 'Verified',
        status: 'Active',
        description: description || ''
      });

      await db.create('activity_logs', {
        type: 'Employer',
        title: 'New Employer Registered',
        description: `${newEmployer.company_name} registered via Admin Panel`,
        user_email: admin.email
      });

      return res.status(201).json({ success: true, message: 'Employer created successfully', employer: newEmployer });
    }

    if (req.method === 'PUT') {
      const { id } = req.query || {};
      const body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
      const targetId = id || body.id;

      if (!targetId) return res.status(400).json({ success: false, error: 'Employer ID required' });

      const updated = await db.update('employers', targetId, body);
      if (!updated) return res.status(404).json({ success: false, error: 'Employer not found' });

      return res.status(200).json({ success: true, message: 'Employer updated successfully', employer: updated });
    }

    if (req.method === 'DELETE') {
      const { id } = req.query || {};
      if (!id) return res.status(400).json({ success: false, error: 'Employer ID required' });

      await db.delete('employers', id);
      return res.status(200).json({ success: true, message: 'Employer deleted successfully' });
    }

    return res.status(405).json({ success: false, error: 'Method not allowed' });
  } catch (error) {
    console.error('Employers API Error:', error);
    return res.status(500).json({ success: false, error: 'Internal server error processing employers request' });
  }
};
