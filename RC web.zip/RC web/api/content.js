// api/content.js - Content Management API for RC Sindhri
const auth = require('../lib/auth');
const db = require('../lib/db');

module.exports = async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Credentials', 'true');
  res.setHeader('Access-Control-Allow-Origin', req.headers.origin || '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') return res.status(200).end();

  // Public GET can fetch website CMS content & public site settings
  if (req.method === 'GET') {
    try {
      const content = await db.getAll('website_content');
      const settings = await db.getAll('site_settings');
      return res.status(200).json({ success: true, content, settings });
    } catch (err) {
      console.error('Content fetch error:', err);
      return res.status(500).json({ success: false, error: 'Failed to load content' });
    }
  }

  // Updating CMS content requires admin authorization
  const admin = auth.verifyAdmin(req);
  if (!admin) {
    return res.status(401).json({ success: false, error: 'Unauthorized. Admin access required.' });
  }

  try {
    if (req.method === 'POST' || req.method === 'PUT') {
      const body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
      const { section_key, title, subtitle, content, language, metadata } = body;

      if (!section_key) {
        return res.status(400).json({ success: false, error: 'section_key is required.' });
      }

      const lang = language || 'en';
      const all = await db.getAll('website_content');
      const existing = all.find(c => c.section_key === section_key && (c.language || 'en') === lang);

      let saved;
      if (existing) {
        const targetId = existing.id || existing.section_key;
        saved = await db.update('website_content', targetId, {
          title: title !== undefined ? title : existing.title,
          subtitle: subtitle !== undefined ? subtitle : existing.subtitle,
          content: content !== undefined ? content : existing.content,
          metadata: metadata || existing.metadata || {},
          updated_at: new Date().toISOString()
        });
      } else {
        saved = await db.create('website_content', {
          section_key,
          language: lang,
          title: title || '',
          subtitle: subtitle || '',
          content: content || '',
          metadata: metadata || {}
        });
      }

      return res.status(200).json({ success: true, message: 'Content updated successfully', content: saved });
    }

    if (req.method === 'DELETE') {
      const { id, section_key } = req.query || {};
      if (!id && !section_key) return res.status(400).json({ success: false, error: 'ID or section_key required' });

      if (id) {
        await db.delete('website_content', id);
      } else if (section_key) {
        const all = await db.getAll('website_content');
        const matches = all.filter(c => c.section_key === section_key);
        for (const m of matches) {
          await db.delete('website_content', m.id);
        }
      }

      return res.status(200).json({ success: true, message: 'Content section deleted successfully' });
    }

    return res.status(405).json({ success: false, error: 'Method not allowed' });
  } catch (error) {
    console.error('Content API Error:', error);
    return res.status(500).json({ success: false, error: 'Failed to update website content' });
  }
};
