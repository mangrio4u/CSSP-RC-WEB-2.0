// api/stats.js - Admin Dashboard Statistics

const auth = require('../lib/auth');
const db = require('../lib/db');

module.exports = async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Credentials', 'true');
  res.setHeader('Access-Control-Allow-Origin', req.headers.origin || '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  const admin = auth.verifyAdmin(req);
  if (!admin) {
    return res.status(401).json({ success: false, error: 'Unauthorized. Please login.' });
  }

  try {
    const stats = await db.getStats();
    return res.status(200).json({
      success: true,
      stats
    });
  } catch (error) {
    console.error('Stats fetch error:', error);
    return res.status(500).json({ success: false, error: 'Failed to retrieve statistics' });
  }
};
