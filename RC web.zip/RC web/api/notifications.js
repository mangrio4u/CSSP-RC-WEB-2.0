// api/notifications.js - Notification Center API for RC Sindhri
const auth = require('../lib/auth');
const db = require('../lib/db');

module.exports = async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Credentials', 'true');
  res.setHeader('Access-Control-Allow-Origin', req.headers.origin || '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,PUT,DELETE,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') return res.status(200).end();

  const admin = auth.verifyAdmin(req);
  if (!admin) {
    return res.status(401).json({ success: false, error: 'Unauthorized' });
  }

  try {
    if (req.method === 'GET') {
      const notifications = await db.getAll('notifications', {}, { orderBy: 'created_at', ascending: false });
      const unreadCount = notifications.filter(n => !n.is_read).length;
      return res.status(200).json({ success: true, notifications, unread_count: unreadCount });
    }

    if (req.method === 'PUT') {
      const { id } = req.query || {};
      const body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
      const targetId = id || body.id || 'all';

      await db.markNotificationRead(targetId);
      return res.status(200).json({ success: true, message: 'Notifications marked as read' });
    }

    if (req.method === 'DELETE') {
      const { id } = req.query || {};
      if (id) {
        await db.delete('notifications', id);
      }
      return res.status(200).json({ success: true, message: 'Notification deleted' });
    }

    return res.status(405).json({ success: false, error: 'Method not allowed' });
  } catch (error) {
    console.error('Notifications API Error:', error);
    return res.status(500).json({ success: false, error: 'Internal server error processing notifications' });
  }
};
