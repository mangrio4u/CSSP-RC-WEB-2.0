// api/activities.js - RC Sindhri Activities Management API
const auth = require('../lib/auth');
const db = require('../lib/db');

module.exports = async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Credentials', 'true');
  res.setHeader('Access-Control-Allow-Origin', req.headers.origin || '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') return res.status(200).end();

  const isPublicGet = req.method === 'GET' && req.query && (req.query.public === 'true' || !req.headers.authorization);

  if (!isPublicGet) {
    const admin = auth.verifyAdmin(req);
    if (!admin) {
      return res.status(401).json({ success: false, error: 'Unauthorized. Admin login required.' });
    }
  }

  try {
    if (req.method === 'GET') {
      const { id, type, project, status, search, limit } = req.query || {};

      if (id) {
        const activity = await db.getById('activities', id);
        if (!activity) return res.status(404).json({ success: false, error: 'Activity not found' });
        return res.status(200).json({ success: true, activity });
      }

      let activities = await db.getAll('activities', {}, { orderBy: 'activity_date', ascending: false });

      if (type && type !== 'all') {
        activities = activities.filter(a => (a.activity_type || '').toLowerCase() === type.toLowerCase());
      }

      if (project && project !== 'all') {
        activities = activities.filter(a => (a.project_name || '').toLowerCase().includes(project.toLowerCase()));
      }

      if (isPublicGet) {
        activities = activities.filter(a => a.status === 'Completed' || a.is_published !== false);
      } else if (status && status !== 'all') {
        activities = activities.filter(a => (a.status || '').toLowerCase() === status.toLowerCase());
      }

      if (search) {
        const s = search.toLowerCase();
        activities = activities.filter(a =>
          (a.title && a.title.toLowerCase().includes(s)) ||
          (a.location && a.location.toLowerCase().includes(s)) ||
          (a.village_name && a.village_name.toLowerCase().includes(s)) ||
          (a.description && a.description.toLowerCase().includes(s))
        );
      }

      if (limit) {
        activities = activities.slice(0, parseInt(limit));
      }

      return res.status(200).json({
        success: true,
        count: activities.length,
        activities
      });
    }

    if (req.method === 'POST') {
      const body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
      const {
        title, activity_type, project_name, activity_date,
        village_name, location, male_participants, female_participants,
        total_participants, topics, facilitators, outcome, description,
        photo_url, status, is_published
      } = body;

      if (!title) {
        return res.status(400).json({ success: false, error: 'Activity title is required.' });
      }

      const male = parseInt(male_participants) || 0;
      const female = parseInt(female_participants) || 0;
      const total = parseInt(total_participants) || (male + female);

      const record = await db.create('activities', {
        title: title.trim(),
        activity_type: activity_type || 'Awareness',
        project_name: project_name || 'RC Sindhri Community Action',
        activity_date: activity_date || new Date().toISOString().split('T')[0],
        village_name: village_name || 'Village Haji Hamer Mangrio',
        location: location || 'UC Sindhri Community Ground',
        male_participants: male,
        female_participants: female,
        total_participants: total,
        topics: topics || '',
        facilitators: facilitators || 'RC Sindhri Team',
        outcome: outcome || '',
        description: description || '',
        photo_url: photo_url || 'https://images.unsplash.com/photo-1542838132-92c53300491e?w=800',
        photos: photo_url ? [photo_url] : [],
        status: status || 'Completed',
        is_published: is_published !== false
      });

      return res.status(201).json({ success: true, message: 'Activity added successfully', activity: record });
    }

    if (req.method === 'PUT') {
      const { id } = req.query || {};
      const body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
      const targetId = id || body.id;

      if (!targetId) return res.status(400).json({ success: false, error: 'Activity ID is required' });

      if (body.male_participants || body.female_participants) {
        const m = parseInt(body.male_participants) || 0;
        const f = parseInt(body.female_participants) || 0;
        if (!body.total_participants) {
          body.total_participants = m + f;
        }
      }

      const updated = await db.update('activities', targetId, body);
      if (!updated) return res.status(404).json({ success: false, error: 'Activity not found' });

      return res.status(200).json({ success: true, message: 'Activity updated successfully', activity: updated });
    }

    if (req.method === 'DELETE') {
      const { id } = req.query || {};
      if (!id) return res.status(400).json({ success: false, error: 'Activity ID is required' });

      await db.delete('activities', id);
      return res.status(200).json({ success: true, message: 'Activity deleted successfully' });
    }

    return res.status(405).json({ success: false, error: 'Method not allowed' });
  } catch (error) {
    console.error('Activities API Error:', error);
    return res.status(500).json({ success: false, error: 'Internal server error processing activity' });
  }
};
