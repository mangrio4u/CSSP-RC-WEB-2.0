// api/jobs.js - Jobs Management API for RC Sindhri
const auth = require('../lib/auth');
const db = require('../lib/db');

module.exports = async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Credentials', 'true');
  res.setHeader('Access-Control-Allow-Origin', req.headers.origin || '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') return res.status(200).end();

  const isPublicGet = req.method === 'GET' && req.query && req.query.public === 'true';

  if (!isPublicGet) {
    const admin = auth.verifyAdmin(req);
    if (!admin) {
      return res.status(401).json({ success: false, error: 'Unauthorized. Admin access required.' });
    }
  }

  try {
    if (req.method === 'GET') {
      const { id, search, status, category, employer_id, location, limit = 50, page = 1 } = req.query || {};

      if (id) {
        const job = await db.getById('jobs', id);
        if (!job) return res.status(404).json({ success: false, error: 'Job not found' });
        return res.status(200).json({ success: true, job });
      }

      let jobs = await db.getAll('jobs', {}, { orderBy: 'created_at', ascending: false });

      if (isPublicGet) {
        jobs = jobs.filter(j => j.status === 'Active' && j.is_published !== false);
      } else {
        if (status && status !== 'all') {
          jobs = jobs.filter(j => j.status.toLowerCase() === status.toLowerCase());
        }
      }

      if (category && category !== 'all') {
        jobs = jobs.filter(j => j.category && j.category.toLowerCase() === category.toLowerCase());
      }
      if (employer_id) {
        jobs = jobs.filter(j => j.employer_id === employer_id);
      }
      if (location && location !== 'all') {
        jobs = jobs.filter(j => j.location && j.location.toLowerCase().includes(location.toLowerCase()));
      }
      if (search) {
        const s = search.toLowerCase();
        jobs = jobs.filter(j => 
          (j.title && j.title.toLowerCase().includes(s)) ||
          (j.employer_name && j.employer_name.toLowerCase().includes(s)) ||
          (j.skills_required && j.skills_required.toLowerCase().includes(s)) ||
          (j.location && j.location.toLowerCase().includes(s))
        );
      }

      const total = jobs.length;
      const startIndex = (parseInt(page) - 1) * parseInt(limit);
      const paginatedJobs = jobs.slice(startIndex, startIndex + parseInt(limit));

      return res.status(200).json({
        success: true,
        jobs: paginatedJobs,
        pagination: { total, page: parseInt(page), limit: parseInt(limit), totalPages: Math.ceil(total / parseInt(limit)) }
      });
    }

    if (req.method === 'POST') {
      const body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
      const {
        title, employer_id, employer_name, category, employment_type,
        location, salary_range, experience_required, education_required,
        skills_required, description, requirements, responsibilities, deadline, status, is_published
      } = body;

      if (!title || !description) {
        return res.status(400).json({ success: false, error: 'Title and description are required.' });
      }

      // If employer_name is provided but employer_id is missing, look up or link
      let finalEmployerName = employer_name;
      if (employer_id && !finalEmployerName) {
        const emp = await db.getById('employers', employer_id);
        if (emp) finalEmployerName = emp.company_name;
      }

      const newJob = await db.create('jobs', {
        title: title.trim(),
        employer_id: employer_id || null,
        employer_name: finalEmployerName || 'RC Sindhri Partner Employer',
        category: category || 'Others',
        employment_type: employment_type || 'Full-time',
        location: location || 'Sindhri',
        salary_range: salary_range || 'Negotiable',
        experience_required: experience_required || 'Not Specified',
        education_required: education_required || 'Not Specified',
        skills_required: skills_required || '',
        description: description.trim(),
        requirements: requirements || '',
        responsibilities: responsibilities || '',
        deadline: deadline || null,
        status: status || 'Active',
        is_published: is_published !== false
      });

      await db.create('activity_logs', {
        type: 'Job',
        title: 'New Job Posted',
        description: `${newJob.title} by ${newJob.employer_name}`,
        user_email: req.admin?.email || 'admin@rcsindhri.org'
      });

      return res.status(201).json({ success: true, message: 'Job created successfully', job: newJob });
    }

    if (req.method === 'PUT') {
      const { id } = req.query || {};
      const body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
      const targetId = id || body.id;

      if (!targetId) return res.status(400).json({ success: false, error: 'Job ID required for update' });

      const updated = await db.update('jobs', targetId, body);
      if (!updated) return res.status(404).json({ success: false, error: 'Job not found' });

      return res.status(200).json({ success: true, message: 'Job updated successfully', job: updated });
    }

    if (req.method === 'DELETE') {
      const { id } = req.query || {};
      if (!id) return res.status(400).json({ success: false, error: 'Job ID required for deletion' });

      await db.delete('jobs', id);
      return res.status(200).json({ success: true, message: 'Job deleted successfully' });
    }

    return res.status(405).json({ success: false, error: 'Method not allowed' });
  } catch (error) {
    console.error('Jobs API Error:', error);
    return res.status(500).json({ success: false, error: 'Internal server error processing jobs request' });
  }
};
