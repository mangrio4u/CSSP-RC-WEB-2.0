// api/candidates.js - Candidates Management API for RC Sindhri
const auth = require('../lib/auth');
const db = require('../lib/db');

module.exports = async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Credentials', 'true');
  res.setHeader('Access-Control-Allow-Origin', req.headers.origin || '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') return res.status(200).end();

  const admin = auth.verifyAdmin(req);
  if (!admin) {
    return res.status(401).json({ success: false, error: 'Unauthorized. Admin access required.' });
  }

  try {
    if (req.method === 'GET') {
      const { id, search, status, trade, limit = 50, page = 1 } = req.query || {};

      if (id) {
        const candidate = await db.getById('candidates', id);
        if (!candidate) return res.status(404).json({ success: false, error: 'Candidate not found' });

        // Retrieve application history
        const applications = await db.getAll('applications', { candidate_id: id });
        return res.status(200).json({ success: true, candidate, applications });
      }

      let candidates = await db.getAll('candidates', {}, { orderBy: 'created_at', ascending: false });

      if (status && status !== 'all') {
        candidates = candidates.filter(c => c.account_status && c.account_status.toLowerCase() === status.toLowerCase());
      }
      if (trade && trade !== 'all') {
        candidates = candidates.filter(c => c.trade_name && c.trade_name.toLowerCase().includes(trade.toLowerCase()));
      }
      if (search) {
        const s = search.toLowerCase();
        candidates = candidates.filter(c =>
          (c.full_name && c.full_name.toLowerCase().includes(s)) ||
          (c.email && c.email.toLowerCase().includes(s)) ||
          (c.phone && c.phone.includes(s)) ||
          (c.skills && c.skills.toLowerCase().includes(s)) ||
          (c.location && c.location.toLowerCase().includes(s)) ||
          (c.village_name && c.village_name.toLowerCase().includes(s))
        );
      }

      const total = candidates.length;
      const startIndex = (parseInt(page) - 1) * parseInt(limit);
      const paginated = candidates.slice(startIndex, startIndex + parseInt(limit));

      return res.status(200).json({
        success: true,
        candidates: paginated,
        pagination: { total, page: parseInt(page), limit: parseInt(limit), totalPages: Math.ceil(total / parseInt(limit)) }
      });
    }

    if (req.method === 'POST') {
      const body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
      const { full_name, email, phone, gender, village_name, location, education, experience_years, skills, trade_name, resume_url, bio } = body;

      if (!full_name) {
        return res.status(400).json({ success: false, error: 'Full name is required.' });
      }

      const newCandidate = await db.create('candidates', {
        full_name: full_name.trim(),
        email: email ? email.trim() : null,
        phone: phone ? phone.trim() : null,
        gender: gender || 'Male',
        village_name: village_name || 'Village Haji Hamer Mangrio',
        location: location || 'Sindhri',
        education: education || '',
        experience_years: experience_years || 'Fresh',
        skills: skills || '',
        trade_name: trade_name || '',
        resume_url: resume_url || '',
        bio: bio || '',
        account_status: 'Active'
      });

      await db.create('activity_logs', {
        type: 'Candidate',
        title: 'New Candidate Registered',
        description: `${newCandidate.full_name} registered via Admin Panel`,
        user_email: admin.email
      });

      return res.status(201).json({ success: true, message: 'Candidate created successfully', candidate: newCandidate });
    }

    if (req.method === 'PUT') {
      const { id } = req.query || {};
      const body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
      const targetId = id || body.id;

      if (!targetId) return res.status(400).json({ success: false, error: 'Candidate ID required' });

      const updated = await db.update('candidates', targetId, body);
      if (!updated) return res.status(404).json({ success: false, error: 'Candidate not found' });

      return res.status(200).json({ success: true, message: 'Candidate updated successfully', candidate: updated });
    }

    if (req.method === 'DELETE') {
      const { id } = req.query || {};
      if (!id) return res.status(400).json({ success: false, error: 'Candidate ID required' });

      await db.delete('candidates', id);
      return res.status(200).json({ success: true, message: 'Candidate deleted successfully' });
    }

    return res.status(405).json({ success: false, error: 'Method not allowed' });
  } catch (error) {
    console.error('Candidates API Error:', error);
    return res.status(500).json({ success: false, error: 'Internal server error processing candidates request' });
  }
};
