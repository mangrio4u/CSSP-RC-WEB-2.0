// api/users.js - User Administration API for RC Sindhri
const auth = require('../lib/auth');
const db = require('../lib/db');

module.exports = async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Credentials', 'true');
  res.setHeader('Access-Control-Allow-Origin', req.headers.origin || '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') return res.status(200).end();

  const admin = auth.verifyAdmin(req);
  if (!admin) {
    return res.status(401).json({ success: false, error: 'Unauthorized. Admin access required.' });
  }

  try {
    if (req.method === 'GET') {
      const { id, search, role, status, limit = 50, page = 1 } = req.query || {};

      if (id) {
        const user = await db.getById('app_users', id);
        if (!user) return res.status(404).json({ success: false, error: 'User not found' });
        return res.status(200).json({ success: true, user });
      }

      let users = await db.getAll('app_users', {}, { orderBy: 'created_at', ascending: false });

      if (role && role !== 'all') {
        users = users.filter(u => u.role && u.role.toLowerCase() === role.toLowerCase());
      }
      if (status && status !== 'all') {
        users = users.filter(u => u.status && u.status.toLowerCase() === status.toLowerCase());
      }
      if (search) {
        const s = search.toLowerCase();
        users = users.filter(u =>
          (u.full_name && u.full_name.toLowerCase().includes(s)) ||
          (u.email && u.email.toLowerCase().includes(s)) ||
          (u.role && u.role.toLowerCase().includes(s))
        );
      }

      const total = users.length;
      const startIndex = (parseInt(page) - 1) * parseInt(limit);
      const paginated = users.slice(startIndex, startIndex + parseInt(limit));

      return res.status(200).json({
        success: true,
        users: paginated,
        pagination: { total, page: parseInt(page), limit: parseInt(limit), totalPages: Math.ceil(total / parseInt(limit)) }
      });
    }

    if (req.method === 'POST') {
      const body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
      const { email, full_name, role, status, phone } = body;

      if (!email || !full_name) {
        return res.status(400).json({ success: false, error: 'Email and full name are required.' });
      }

      const existing = await db.getAll('app_users', { email: email.trim().toLowerCase() });
      if (existing.length > 0) {
        return res.status(400).json({ success: false, error: 'User with this email already exists.' });
      }

      const newUser = await db.create('app_users', {
        email: email.trim().toLowerCase(),
        full_name: full_name.trim(),
        role: role || 'Staff',
        status: status || 'Active',
        phone: phone || '',
        last_login: null
      });

      await db.create('activity_logs', {
        type: 'User',
        title: 'New User Registered',
        description: `${newUser.full_name} (${newUser.role}) added by ${admin.email}`,
        user_email: admin.email
      });

      return res.status(201).json({ success: true, message: 'User created successfully', user: newUser });
    }

    if (req.method === 'PUT') {
      const { id } = req.query || {};
      const body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
      const targetId = id || body.id;

      if (!targetId) return res.status(400).json({ success: false, error: 'User ID required' });

      const updated = await db.update('app_users', targetId, body);
      if (!updated) return res.status(404).json({ success: false, error: 'User not found' });

      return res.status(200).json({ success: true, message: 'User updated successfully', user: updated });
    }

    if (req.method === 'DELETE') {
      const { id } = req.query || {};
      if (!id) return res.status(400).json({ success: false, error: 'User ID required' });

      await db.delete('app_users', id);
      return res.status(200).json({ success: true, message: 'User deleted successfully' });
    }

    return res.status(405).json({ success: false, error: 'Method not allowed' });
  } catch (error) {
    console.error('Users API Error:', error);
    return res.status(500).json({ success: false, error: 'Internal server error processing user request' });
  }
};
