// api/statistics.js - RC Statistics & Numbers Management API
const auth = require('../lib/auth');
const db = require('../lib/db');

module.exports = async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Credentials', 'true');
  res.setHeader('Access-Control-Allow-Origin', req.headers.origin || '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') return res.status(200).end();

  const isPublicGet = req.method === 'GET' && req.query && (req.query.public === 'true' || !req.headers.authorization);

  if (!isPublicGet) {
    const admin = auth.verifyAdmin(req);
    if (!admin) {
      return res.status(401).json({ success: false, error: 'Unauthorized. Admin login required.' });
    }
  }

  try {
    if (req.method === 'GET') {
      const impactStats = await db.getAll('impact_statistics', {}, { orderBy: 'display_order', ascending: true });
      const members = await db.getAll('community_members');
      const activities = await db.getAll('activities');
      const projects = await db.getAll('projects');
      const albums = await db.getAll('albums');

      // Key-value dictionary
      const statsMap = {};
      impactStats.forEach(s => {
        statsMap[s.stat_key] = {
          id: s.id,
          raw_value: s.raw_value,
          display_value: s.display_value,
          label: s.label,
          category: s.category || 'general',
          icon: s.icon || 'fa-solid fa-chart-line',
          display_order: s.display_order || 0
        };
      });

      return res.status(200).json({
        success: true,
        statistics: {
          trainees: statsMap['vocational_trainees']?.display_value || '240',
          youth_groups: statsMap['youth_groups']?.display_value || '8',
          youth_members: statsMap['youth_members']?.display_value || '200',
          awareness_sessions: statsMap['awareness_sessions']?.display_value || '50+',
          stage_drama: statsMap['stage_drama']?.display_value || '10',
          nic_cards: statsMap['nic_cards']?.display_value || '160',
          livelihoods: statsMap['livelihood_cases']?.display_value || '15+',
          villages: statsMap['villages_covered']?.display_value || '18',
          climate_youth: statsMap['climate_trained_youth']?.display_value || '100',
          health_reached: statsMap['health_reached']?.display_value || '560+',
          total_members: members.length.toString(),
          total_activities: activities.length.toString(),
          total_programs: projects.length.toString(),
          total_albums: albums.length.toString()
        },
        raw_list: impactStats
      });
    }

    if (req.method === 'POST') {
      const body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
      const { stat_key, label, display_value, raw_value, icon, category, display_order } = body;

      if (!stat_key || !label) {
        return res.status(400).json({ success: false, error: 'stat_key and label are required.' });
      }

      const valStr = String(display_value || '0').trim();
      const numVal = raw_value !== undefined ? Number(raw_value) : (parseInt(valStr.replace(/[^0-9]/g, '')) || 0);

      const newStat = await db.create('impact_statistics', {
        stat_key: stat_key.trim().toLowerCase().replace(/\s+/g, '_'),
        label: label.trim(),
        display_value: valStr,
        raw_value: numVal,
        icon: icon || 'fa-solid fa-chart-pie',
        category: category || 'general',
        display_order: parseInt(display_order) || 10,
        is_active: true
      });

      return res.status(201).json({ success: true, message: 'Statistic added successfully', stat: newStat });
    }

    if (req.method === 'PUT') {
      const { id } = req.query || {};
      const body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;

      // Single stat update by ID
      if (id || (body.id && !body.statistics)) {
        const targetId = id || body.id;
        const valStr = body.display_value !== undefined ? String(body.display_value).trim() : undefined;
        const rawNum = body.raw_value !== undefined ? Number(body.raw_value) : (valStr ? parseInt(valStr.replace(/[^0-9]/g, '')) || 0 : undefined);

        const updates = { ...body };
        if (valStr !== undefined) updates.display_value = valStr;
        if (rawNum !== undefined) updates.raw_value = rawNum;
        delete updates.id;

        const updated = await db.update('impact_statistics', targetId, updates);
        return res.status(200).json({ success: true, message: 'Statistic updated successfully', stat: updated });
      }

      // Bulk statistics object update: { statistics: { key: val, ... } }
      const { statistics } = body;
      if (!statistics || typeof statistics !== 'object') {
        return res.status(400).json({ success: false, error: 'Valid statistics object required' });
      }

      const allStats = await db.getAll('impact_statistics');

      for (const [key, val] of Object.entries(statistics)) {
        const valStr = String(val).trim();
        const rawNum = parseInt(valStr.replace(/[^0-9]/g, '')) || 0;

        const existing = allStats.find(s => s.stat_key === key);
        if (existing) {
          const targetKey = existing.id || existing.stat_key;
          await db.update('impact_statistics', targetKey, {
            display_value: valStr,
            raw_value: rawNum,
            updated_at: new Date().toISOString()
          });
        } else {
          await db.create('impact_statistics', {
            stat_key: key,
            label: key.replace(/_/g, ' ').toUpperCase(),
            raw_value: rawNum,
            display_value: valStr,
            category: 'general'
          });
        }
      }

      return res.status(200).json({ success: true, message: 'All statistics updated and saved successfully' });
    }

    if (req.method === 'DELETE') {
      const { id, key } = req.query || {};
      if (!id && !key) return res.status(400).json({ success: false, error: 'Stat ID or key required' });

      if (id) {
        await db.delete('impact_statistics', id);
      } else if (key) {
        const allStats = await db.getAll('impact_statistics');
        const match = allStats.find(s => s.stat_key === key);
        if (match) await db.delete('impact_statistics', match.id);
      }

      return res.status(200).json({ success: true, message: 'Statistic deleted successfully' });
    }

    return res.status(405).json({ success: false, error: 'Method not allowed' });
  } catch (error) {
    console.error('Statistics API Error:', error);
    return res.status(500).json({ success: false, error: 'Failed to process statistics' });
  }
};
