// api/submissions/moderate.js - Admin Moderation Actions

const auth = require('../../lib/auth');
const db = require('../../lib/db');

module.exports = async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Credentials', 'true');
  res.setHeader('Access-Control-Allow-Origin', req.headers.origin || '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST,PUT,DELETE,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  const admin = auth.verifyAdmin(req);
  if (!admin) {
    return res.status(401).json({ success: false, error: 'Unauthorized' });
  }

  let body = req.body;
  if (typeof body === 'string') {
    try { body = JSON.parse(body); } catch (e) {}
  }

  const { id } = req.query.id ? req.query : (body || {});

  if (!id) {
    return res.status(400).json({ success: false, error: 'Photo/Submission ID is required' });
  }

  // DELETE: Delete submission/photo
  if (req.method === 'DELETE') {
    try {
      const deleted = await db.deletePhoto(id);
      if (!deleted) {
        return res.status(404).json({ success: false, error: 'Photo not found' });
      }
      return res.status(200).json({ success: true, message: 'Photo deleted successfully' });
    } catch (error) {
      console.error('Delete photo error:', error);
      return res.status(500).json({ success: false, error: 'Failed to delete photo' });
    }
  }

  // POST or PUT: Moderation actions (approve, reject, move, edit, unpublish)
  if (req.method === 'POST' || req.method === 'PUT') {
    try {
      const { action, album_id, title, description, location, is_published } = body || {};

      const existing = await db.getPhotoById(id);
      if (!existing) {
        return res.status(404).json({ success: false, error: 'Photo/Submission not found' });
      }

      const updates = {};
      if (title !== undefined) updates.title = title.trim();
      if (description !== undefined) updates.description = description.trim();
      if (location !== undefined) updates.location = location.trim();
      if (album_id !== undefined) updates.album_id = album_id || null;

      if (action === 'approve') {
        updates.status = 'approved';
        updates.is_published = true;
        updates.reviewed_at = new Date().toISOString();
        updates.reviewed_by = admin.email;
        if (album_id !== undefined) updates.album_id = album_id;
      } else if (action === 'reject') {
        updates.status = 'rejected';
        updates.is_published = false;
        updates.reviewed_at = new Date().toISOString();
        updates.reviewed_by = admin.email;
      } else if (action === 'unpublish') {
        updates.is_published = false;
      } else if (action === 'publish') {
        updates.status = 'approved';
        updates.is_published = true;
      }

      if (is_published !== undefined) {
        updates.is_published = !!is_published;
      }

      const updated = await db.updatePhoto(id, updates);
      return res.status(200).json({
        success: true,
        message: `Photo ${action || 'updated'} successfully`,
        photo: updated
      });
    } catch (error) {
      console.error('Moderation error:', error);
      return res.status(500).json({ success: false, error: 'Failed to process moderation action' });
    }
  }

  return res.status(405).json({ success: false, error: 'Method Not Allowed' });
};
