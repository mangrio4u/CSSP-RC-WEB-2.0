// api/submissions/index.js - Public Photo Submission & Admin Moderation Queue

const auth = require('../../lib/auth');
const db = require('../../lib/db');
const imgbb = require('../../lib/imgbb');

module.exports = async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Credentials', 'true');
  res.setHeader('Access-Control-Allow-Origin', req.headers.origin || '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  // GET: Admin moderation list
  if (req.method === 'GET') {
    const admin = auth.verifyAdmin(req);
    if (!admin) {
      return res.status(401).json({ success: false, error: 'Unauthorized' });
    }

    try {
      const { status, album_id } = req.query;
      const filters = {};
      if (status && status !== 'all') {
        filters.status = status;
      }
      if (album_id) {
        filters.album_id = album_id;
      }

      const submissions = await db.getPhotos(filters);
      return res.status(200).json({ success: true, submissions });
    } catch (error) {
      console.error('Submissions fetch error:', error);
      return res.status(500).json({ success: false, error: 'Failed to retrieve submissions' });
    }
  }

  // POST: Public photo submission (Or direct Admin submission)
  if (req.method === 'POST') {
    try {
      let body = req.body;
      if (typeof body === 'string') {
        try { body = JSON.parse(body); } catch (e) {}
      }

      const {
        title,
        description,
        location,
        album_id,
        submitter_name,
        submitter_email,
        submitter_phone,
        consent_given,
        imageBase64,
        imageUrl
      } = body || {};

      if (!title || !title.trim()) {
        return res.status(400).json({ success: false, error: 'Photo title is required' });
      }

      if (!imageBase64 && !imageUrl) {
        return res.status(400).json({ success: false, error: 'Photo image file or URL is required' });
      }

      if (consent_given === false || consent_given === 'false') {
        return res.status(400).json({ success: false, error: 'You must confirm permission to share this photo' });
      }

      let finalImageUrl = imageUrl;
      let finalThumbUrl = imageUrl;
      let finalDeleteUrl = null;

      // If base64 is provided (or passed in imageUrl), upload to ImgBB
      const rawCandidate = imageBase64 || (imageUrl && imgbb.isBase64Image(imageUrl) ? imageUrl : null);
      if (rawCandidate) {
        const uploadResult = await imgbb.uploadImage(rawCandidate, title.trim());
        if (!uploadResult.success) {
          return res.status(502).json({
            success: false,
            error: `Image hosting upload failed: ${uploadResult.error}`
          });
        }
        finalImageUrl = uploadResult.data.display_url || uploadResult.data.url;
        finalThumbUrl = (uploadResult.data.thumb && uploadResult.data.thumb.url) || finalImageUrl;
        finalDeleteUrl = uploadResult.data.delete_url || null;
      }

      if (!finalImageUrl || imgbb.isBase64Image(finalImageUrl)) {
        return res.status(400).json({ success: false, error: 'Valid hosted image URL is required. Base64 cannot be stored directly.' });
      }

      // Check if this is an admin uploading directly
      const admin = auth.verifyAdmin(req);
      const isDirectAdminUpload = !!admin && body.auto_approve === true;

      const newPhoto = await db.createPhotoSubmission({
        title: title.trim(),
        description: description ? description.trim() : '',
        location: location ? location.trim() : '',
        album_id: album_id || null,
        image_url: finalImageUrl,
        thumbnail_url: finalThumbUrl,
        delete_url: finalDeleteUrl,
        submitter_name: submitter_name ? submitter_name.trim() : (isDirectAdminUpload ? admin.name : 'Community Contributor'),
        submitter_email: submitter_email ? submitter_email.trim() : (isDirectAdminUpload ? admin.email : null),
        submitter_phone: submitter_phone ? submitter_phone.trim() : null,
        consent_given: true,
        status: isDirectAdminUpload ? 'approved' : 'pending',
        is_published: isDirectAdminUpload ? true : false,
        reviewed_at: isDirectAdminUpload ? new Date().toISOString() : null,
        reviewed_by: isDirectAdminUpload ? admin.email : null
      });

      return res.status(201).json({
        success: true,
        message: isDirectAdminUpload 
          ? 'Photo uploaded and published to gallery successfully!' 
          : 'Thank you! Your photo has been submitted successfully and will appear in the gallery once reviewed by the RC Sindhri team.',
        submission: newPhoto
      });
    } catch (error) {
      console.error('Photo submission error:', error);
      return res.status(500).json({ success: false, error: 'Internal server error during photo submission' });
    }
  }

  return res.status(405).json({ success: false, error: 'Method Not Allowed' });
};
