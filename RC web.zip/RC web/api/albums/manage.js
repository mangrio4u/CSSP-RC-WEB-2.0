// api/albums/manage.js - Edit & Delete Albums

const auth = require('../../lib/auth');
const db = require('../../lib/db');

module.exports = async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Credentials', 'true');
  res.setHeader('Access-Control-Allow-Origin', req.headers.origin || '*');
  res.setHeader('Access-Control-Allow-Methods', 'PUT,DELETE,GET,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  const admin = auth.verifyAdmin(req);
  if (!admin) {
    return res.status(401).json({ success: false, error: 'Unauthorized' });
  }

  const { id } = req.query;
  if (!id) {
    return res.status(400).json({ success: false, error: 'Album ID is required' });
  }

  // GET single album
  if (req.method === 'GET') {
    const album = await db.getAlbumByIdOrSlug(id);
    if (!album) return res.status(404).json({ success: false, error: 'Album not found' });
    return res.status(200).json({ success: true, album });
  }

  // PUT: Update album
  if (req.method === 'PUT') {
    try {
      let body = req.body;
      if (typeof body === 'string') {
        try { body = JSON.parse(body); } catch (e) {}
      }

      const { title, slug, description, cover_image_url, is_visible, display_order } = body || {};

      const updates = {};
      if (title !== undefined) updates.title = title.trim();
      if (slug !== undefined) updates.slug = slug.trim().toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
      if (description !== undefined) updates.description = description.trim();
      if (cover_image_url !== undefined) updates.cover_image_url = cover_image_url;
      if (is_visible !== undefined) updates.is_visible = !!is_visible;
      if (display_order !== undefined) updates.display_order = Number(display_order);

      const updated = await db.updateAlbum(id, updates);
      if (!updated) {
        return res.status(404).json({ success: false, error: 'Album not found' });
      }

      return res.status(200).json({ success: true, message: 'Album updated successfully', album: updated });
    } catch (error) {
      console.error('Album update error:', error);
      return res.status(500).json({ success: false, error: 'Failed to update album' });
    }
  }

  // DELETE: Delete album safely
  if (req.method === 'DELETE') {
    try {
      const deleted = await db.deleteAlbum(id);
      if (!deleted) {
        return res.status(404).json({ success: false, error: 'Album not found or failed to delete' });
      }
      return res.status(200).json({ success: true, message: 'Album deleted safely. Photos reassigned.' });
    } catch (error) {
      console.error('Album deletion error:', error);
      return res.status(500).json({ success: false, error: 'Failed to delete album' });
    }
  }

  return res.status(405).json({ success: false, error: 'Method Not Allowed' });
};
