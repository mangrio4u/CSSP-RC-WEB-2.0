// api/albums/index.js - List & Create Albums

const auth = require('../../lib/auth');
const db = require('../../lib/db');

module.exports = async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Credentials', 'true');
  res.setHeader('Access-Control-Allow-Origin', req.headers.origin || '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  // GET: List albums (public or all for admin)
  if (req.method === 'GET') {
    try {
      const admin = auth.verifyAdmin(req);
      const onlyVisible = !admin && req.query.all !== 'true';
      const albums = await db.getAlbums(onlyVisible);
      return res.status(200).json({ success: true, albums });
    } catch (error) {
      return res.status(500).json({ success: false, error: 'Failed to retrieve albums' });
    }
  }

  // POST: Create album (Admin only)
  if (req.method === 'POST') {
    const admin = auth.verifyAdmin(req);
    if (!admin) {
      return res.status(401).json({ success: false, error: 'Unauthorized' });
    }

    try {
      let body = req.body;
      if (typeof body === 'string') {
        try { body = JSON.parse(body); } catch (e) {}
      }

      const { title, slug, description, cover_image_url, is_visible, display_order } = body || {};

      if (!title || !title.trim()) {
        return res.status(400).json({ success: false, error: 'Album title is required' });
      }

      const generatedSlug = slug ? slug.trim().toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '') : title.trim().toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');

      // Check for duplicate slug
      const existing = await db.getAlbumByIdOrSlug(generatedSlug);
      if (existing) {
        return res.status(400).json({ success: false, error: 'An album with this slug/title already exists' });
      }

      const newAlbum = await db.createAlbum({
        title: title.trim(),
        slug: generatedSlug,
        description: description ? description.trim() : '',
        cover_image_url: cover_image_url || null,
        is_visible: is_visible !== undefined ? is_visible : true,
        display_order: Number(display_order) || 0
      });

      return res.status(201).json({ success: true, message: 'Album created successfully', album: newAlbum });
    } catch (error) {
      console.error('Album creation error:', error);
      return res.status(500).json({ success: false, error: 'Failed to create album' });
    }
  }

  return res.status(405).json({ success: false, error: 'Method Not Allowed' });
};
