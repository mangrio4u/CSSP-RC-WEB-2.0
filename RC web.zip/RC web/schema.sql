-- ==============================================================================
-- RC Sindhri (Rozgar Center Sindhri) - Enterprise Database Schema
-- Production Schema for Supabase (PostgreSQL)
-- Location: Village Haji Hamer Mangrio, UC Sindhri, Taluka Sindhri, Mirpur Khas, Sindh
-- Tagline: "From Youth Potential to Community Impact"
-- ==============================================================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ==============================================================================
-- 1. AUTHENTICATION, ADMINS & ROLES
-- ==============================================================================
CREATE TABLE IF NOT EXISTS admins (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    name TEXT NOT NULL DEFAULT 'Administrator',
    role TEXT NOT NULL DEFAULT 'admin' CHECK (role IN ('super_admin', 'admin', 'editor', 'viewer')),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    last_login TIMESTAMPTZ
);

-- ==============================================================================
-- 2. VILLAGES (18 Verified Villages across UC Sindhri)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS villages (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    name TEXT UNIQUE NOT NULL,
    uc TEXT NOT NULL DEFAULT 'Sindhri',
    taluka TEXT NOT NULL DEFAULT 'Sindhri',
    district TEXT NOT NULL DEFAULT 'Mirpur Khas',
    latitude NUMERIC(10, 7),
    longitude NUMERIC(10, 7),
    description TEXT,
    population INTEGER,
    status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
    image_url TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ==============================================================================
-- 3. DESIGNATIONS
-- ==============================================================================
CREATE TABLE IF NOT EXISTS designations (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    title TEXT UNIQUE NOT NULL,
    description TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    display_order INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ==============================================================================
-- 4. COMMUNITY MEMBERS
-- Sensitive information (CNIC, personal phone) must NOT appear on public website
-- ==============================================================================
CREATE TABLE IF NOT EXISTS community_members (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    full_name TEXT NOT NULL,
    father_husband_name TEXT,
    gender TEXT CHECK (gender IN ('Male', 'Female', 'Other')),
    date_of_birth DATE,
    cnic TEXT, -- Strictly private
    mobile_number TEXT, -- Strictly private
    whatsapp_number TEXT,
    email TEXT,
    address TEXT,
    village_id UUID REFERENCES villages(id) ON DELETE SET NULL,
    village_name TEXT,
    uc TEXT DEFAULT 'Sindhri',
    taluka TEXT DEFAULT 'Sindhri',
    district TEXT DEFAULT 'Mirpur Khas',
    designation_id UUID REFERENCES designations(id) ON DELETE SET NULL,
    designation_title TEXT,
    department_area TEXT,
    education TEXT,
    skills TEXT,
    short_bio TEXT,
    joining_date DATE,
    social_links JSONB DEFAULT '{}'::jsonb,
    profile_image_url TEXT,
    committee_type TEXT NOT NULL DEFAULT 'management' CHECK (committee_type IN ('management', 'pty', 'manzil', 'drama', 'general')),
    display_order INTEGER DEFAULT 10,
    status TEXT NOT NULL DEFAULT 'Active' CHECK (status IN ('Active', 'Inactive', 'Former Member')),
    is_archived BOOLEAN DEFAULT FALSE,
    is_public BOOLEAN DEFAULT TRUE, -- Controls display on public team page
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ==============================================================================
-- 5. PROJECTS (PTY, MANZIL, Community Development, Vocational Training)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS projects (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    name TEXT NOT NULL,
    short_name TEXT UNIQUE NOT NULL,
    description TEXT NOT NULL,
    project_type TEXT DEFAULT 'Youth & Community Development',
    start_date DATE,
    end_date DATE,
    status TEXT NOT NULL DEFAULT 'Active' CHECK (status IN ('Active', 'Completed', 'Ongoing', 'Planned')),
    location TEXT DEFAULT 'UC Sindhri, Mirpur Khas',
    partner TEXT,
    funding_info TEXT,
    objectives TEXT,
    achievements TEXT,
    impact TEXT,
    project_image_url TEXT,
    project_logo_url TEXT,
    project_manager TEXT,
    is_published BOOLEAN DEFAULT TRUE,
    display_order INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ==============================================================================
-- 6. YOUTH GROUPS (PTY Focus: 8 Groups, 200 Members, 2 Girls' Groups)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS youth_groups (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    name TEXT NOT NULL,
    project_id UUID REFERENCES projects(id) ON DELETE SET NULL,
    village_id UUID REFERENCES villages(id) ON DELETE SET NULL,
    village_name TEXT,
    group_type TEXT NOT NULL DEFAULT 'Boys' CHECK (group_type IN ('Boys', 'Girls', 'Mixed')),
    member_count INTEGER DEFAULT 25,
    target_members INTEGER DEFAULT 25,
    formation_date DATE,
    focal_person TEXT,
    status TEXT NOT NULL DEFAULT 'Active' CHECK (status IN ('Active', 'Inactive')),
    description TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS youth_group_members (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    group_id UUID REFERENCES youth_groups(id) ON DELETE CASCADE,
    member_name TEXT NOT NULL,
    gender TEXT CHECK (gender IN ('Male', 'Female')),
    village_id UUID REFERENCES villages(id) ON DELETE SET NULL,
    contact_number TEXT,
    role TEXT DEFAULT 'Member' CHECK (role IN ('President', 'Focal Person', 'Secretary', 'Member', 'Volunteer')),
    joined_date DATE DEFAULT CURRENT_DATE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ==============================================================================
-- 7. TRADES (7 Verified Vocational Trades: Total 240 Trainees)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS trades (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    name TEXT UNIQUE NOT NULL,
    description TEXT,
    duration TEXT DEFAULT '3 Months',
    total_trainees_count INTEGER DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    display_order INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ==============================================================================
-- 8. TRAININGS
-- ==============================================================================
CREATE TABLE IF NOT EXISTS trainings (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    title TEXT NOT NULL,
    project_id UUID REFERENCES projects(id) ON DELETE SET NULL,
    trade_id UUID REFERENCES trades(id) ON DELETE SET NULL,
    trade_name TEXT,
    trainer_name TEXT,
    start_date DATE,
    end_date DATE,
    duration TEXT,
    location TEXT,
    village_id UUID REFERENCES villages(id) ON DELETE SET NULL,
    male_participants INTEGER DEFAULT 0,
    female_participants INTEGER DEFAULT 0,
    total_participants INTEGER DEFAULT 0,
    skills_learned TEXT,
    description TEXT,
    photos JSONB DEFAULT '[]'::jsonb,
    status TEXT NOT NULL DEFAULT 'Completed' CHECK (status IN ('Completed', 'Ongoing', 'Planned')),
    is_published BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ==============================================================================
-- 9. EMPLOYMENT & LIVELIHOOD (15+ Youth Earning)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS employment_records (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    youth_name TEXT NOT NULL,
    gender TEXT DEFAULT 'Male',
    village_id UUID REFERENCES villages(id) ON DELETE SET NULL,
    village_name TEXT,
    trade_id UUID REFERENCES trades(id) ON DELETE SET NULL,
    trade_name TEXT,
    employment_type TEXT NOT NULL CHECK (employment_type IN ('Wage Employment', 'Self Employed', 'Contract', 'Apprenticeship')),
    employer_business TEXT,
    monthly_income TEXT,
    location TEXT,
    start_date DATE,
    status TEXT NOT NULL DEFAULT 'Active' CHECK (status IN ('Active', 'Former', 'Relocated')),
    description TEXT,
    verification_status TEXT NOT NULL DEFAULT 'Verified' CHECK (verification_status IN ('Verified', 'Pending', 'Unverified')),
    photo_url TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ==============================================================================
-- 10. ENTREPRENEURSHIP (15+ Youth Businesses)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS entrepreneurs (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    youth_name TEXT NOT NULL,
    gender TEXT DEFAULT 'Male',
    village_id UUID REFERENCES villages(id) ON DELETE SET NULL,
    village_name TEXT,
    business_name TEXT NOT NULL,
    business_type TEXT NOT NULL,
    trade_id UUID REFERENCES trades(id) ON DELETE SET NULL,
    trade_name TEXT,
    location TEXT,
    start_date DATE,
    initial_investment TEXT,
    status TEXT NOT NULL DEFAULT 'Active' CHECK (status IN ('Active', 'Developing', 'Closed')),
    description TEXT,
    verification_status TEXT NOT NULL DEFAULT 'Verified' CHECK (verification_status IN ('Verified', 'Pending', 'Unverified')),
    photo_url TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ==============================================================================
-- 11. EDUCATION ADVOCACY ACHIEVEMENTS
-- ==============================================================================
CREATE TABLE IF NOT EXISTS education_achievements (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    institution TEXT NOT NULL,
    institution_type TEXT NOT NULL CHECK (institution_type IN ('Primary School', 'Middle School', 'High School', 'Higher Secondary School', 'College', 'Community Center')),
    village_id UUID REFERENCES villages(id) ON DELETE SET NULL,
    village_name TEXT,
    achievement TEXT NOT NULL,
    previous_situation TEXT,
    advocacy_intervention TEXT,
    current_situation TEXT,
    student_count INTEGER DEFAULT 0,
    girls_count INTEGER DEFAULT 0,
    boys_count INTEGER DEFAULT 0,
    description TEXT,
    photos JSONB DEFAULT '[]'::jsonb,
    documents JSONB DEFAULT '[]'::jsonb,
    achievement_date DATE,
    is_published BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ==============================================================================
-- 12. PUBLIC SERVICES & NADRA MRV FACILITATION
-- ==============================================================================
CREATE TABLE IF NOT EXISTS public_services (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    service_type TEXT NOT NULL DEFAULT 'NADRA Mobile Registration Van',
    department TEXT NOT NULL DEFAULT 'NADRA',
    service_date DATE,
    location TEXT NOT NULL,
    village_id UUID REFERENCES villages(id) ON DELETE SET NULL,
    tokens_issued INTEGER DEFAULT 0,
    applications_received INTEGER DEFAULT 0,
    successful_cases INTEGER DEFAULT 0,
    rejected_cases INTEGER DEFAULT 0,
    expired_cases INTEGER DEFAULT 0,
    notes TEXT,
    photos JSONB DEFAULT '[]'::jsonb,
    documents JSONB DEFAULT '[]'::jsonb,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ==============================================================================
-- 13. GOVERNMENT ENGAGEMENT
-- ==============================================================================
CREATE TABLE IF NOT EXISTS government_engagements (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    department TEXT NOT NULL,
    official_name TEXT NOT NULL,
    designation TEXT NOT NULL,
    meeting_date DATE,
    location TEXT,
    purpose TEXT NOT NULL,
    discussion TEXT,
    outcome TEXT,
    follow_up TEXT,
    photos JSONB DEFAULT '[]'::jsonb,
    documents JSONB DEFAULT '[]'::jsonb,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ==============================================================================
-- 14. COMMUNITY OUTREACH & ACTIVITIES (19 Categories)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS activities (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    title TEXT NOT NULL,
    project_id UUID REFERENCES projects(id) ON DELETE SET NULL,
    project_name TEXT,
    activity_type TEXT NOT NULL CHECK (activity_type IN (
        'Awareness', 'Youth Meeting', 'Community Meeting', 'Training', 
        'Health', 'Vaccination', 'Climate', 'Education', 'GBV', 
        'Employment', 'Livelihood', 'Entrepreneurship', 'Tree Plantation', 
        'Cultural', 'Stage Drama', 'Mach Kachehri', 'Government Engagement', 
        'NADRA Facilitation', 'Other'
    )),
    activity_date DATE,
    village_id UUID REFERENCES villages(id) ON DELETE SET NULL,
    village_name TEXT,
    location TEXT,
    description TEXT,
    male_participants INTEGER DEFAULT 0,
    female_participants INTEGER DEFAULT 0,
    total_participants INTEGER DEFAULT 0,
    topics TEXT,
    facilitators TEXT,
    outcome TEXT,
    photos JSONB DEFAULT '[]'::jsonb,
    documents JSONB DEFAULT '[]'::jsonb,
    status TEXT NOT NULL DEFAULT 'Completed' CHECK (status IN ('Completed', 'Ongoing', 'Planned')),
    is_published BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ==============================================================================
-- 15. EVENTS
-- ==============================================================================
CREATE TABLE IF NOT EXISTS events (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    title TEXT NOT NULL,
    event_date DATE,
    location TEXT,
    project_id UUID REFERENCES projects(id) ON DELETE SET NULL,
    category TEXT DEFAULT 'Community Event',
    description TEXT,
    participants_count INTEGER DEFAULT 0,
    photos JSONB DEFAULT '[]'::jsonb,
    documents JSONB DEFAULT '[]'::jsonb,
    is_featured BOOLEAN DEFAULT FALSE,
    is_published BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ==============================================================================
-- 16. ALBUMS & PHOTO GALLERY
-- ==============================================================================
CREATE TABLE IF NOT EXISTS albums (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    slug TEXT UNIQUE NOT NULL,
    title TEXT NOT NULL,
    description TEXT,
    cover_image_url TEXT,
    is_visible BOOLEAN DEFAULT TRUE,
    display_order INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS photos (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    album_id UUID REFERENCES albums(id) ON DELETE SET NULL,
    project_id UUID REFERENCES projects(id) ON DELETE SET NULL,
    activity_id UUID REFERENCES activities(id) ON DELETE SET NULL,
    village_id UUID REFERENCES villages(id) ON DELETE SET NULL,
    title TEXT NOT NULL,
    description TEXT,
    location TEXT,
    image_url TEXT NOT NULL,
    thumbnail_url TEXT,
    delete_url TEXT,
    submitter_name TEXT,
    submitter_email TEXT,
    submitter_phone TEXT,
    consent_given BOOLEAN DEFAULT TRUE,
    status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
    is_published BOOLEAN DEFAULT FALSE,
    is_featured BOOLEAN DEFAULT FALSE,
    display_order INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    reviewed_at TIMESTAMPTZ,
    reviewed_by TEXT
);

-- ==============================================================================
-- 17. REPORTS & DOCUMENTS
-- ==============================================================================
CREATE TABLE IF NOT EXISTS documents (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    title TEXT NOT NULL,
    project_id UUID REFERENCES projects(id) ON DELETE SET NULL,
    document_type TEXT NOT NULL CHECK (document_type IN ('PDF', 'DOC/DOCX', 'XLS/XLSX', 'PPT/PPTX', 'Image', 'Publication')),
    year INTEGER DEFAULT EXTRACT(YEAR FROM CURRENT_DATE),
    description TEXT,
    file_url TEXT NOT NULL,
    file_size TEXT,
    is_public BOOLEAN DEFAULT TRUE,
    is_featured BOOLEAN DEFAULT FALSE,
    upload_date DATE DEFAULT CURRENT_DATE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ==============================================================================
-- 18. WEBSITE CONTENT CMS (Multi-language: English, Urdu, Sindhi)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS website_content (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    section_key TEXT NOT NULL, -- e.g. 'home_hero', 'about_mission', 'contact_info', 'footer'
    language TEXT NOT NULL DEFAULT 'en' CHECK (language IN ('en', 'ur', 'sd')),
    title TEXT,
    subtitle TEXT,
    content TEXT,
    metadata JSONB DEFAULT '{}'::jsonb,
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(section_key, language)
);

-- ==============================================================================
-- 19. IMPACT STATISTICS (Auto-calculated & Manually Verified with Display Format)
-- ==============================================================================
CREATE TABLE IF NOT EXISTS impact_statistics (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    stat_key TEXT UNIQUE NOT NULL,
    label TEXT NOT NULL,
    raw_value NUMERIC NOT NULL,
    display_value TEXT NOT NULL, -- e.g. '240', '15+', '50+'
    icon TEXT DEFAULT 'fa-solid fa-chart-line',
    category TEXT DEFAULT 'general',
    is_auto_calculated BOOLEAN DEFAULT FALSE,
    display_order INTEGER DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ==============================================================================
-- 20. AUDIT LOGS
-- ==============================================================================
CREATE TABLE IF NOT EXISTS audit_logs (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_email TEXT NOT NULL,
    action TEXT NOT NULL,
    table_name TEXT NOT NULL,
    record_id TEXT,
    old_values JSONB,
    new_values JSONB,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ==============================================================================
-- 21. SITE SETTINGS
-- ==============================================================================
CREATE TABLE IF NOT EXISTS site_settings (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    setting_key TEXT UNIQUE NOT NULL,
    setting_value TEXT NOT NULL,
    description TEXT,
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ==============================================================================
-- 22. PERFORMANCE INDEXES
-- ==============================================================================
CREATE INDEX IF NOT EXISTS idx_members_village ON community_members(village_id);
CREATE INDEX IF NOT EXISTS idx_members_designation ON community_members(designation_id);
CREATE INDEX IF NOT EXISTS idx_members_status ON community_members(status);
CREATE INDEX IF NOT EXISTS idx_activities_project ON activities(project_id);
CREATE INDEX IF NOT EXISTS idx_activities_type ON activities(activity_type);
CREATE INDEX IF NOT EXISTS idx_activities_date ON activities(activity_date DESC);
CREATE INDEX IF NOT EXISTS idx_trainings_trade ON trainings(trade_id);
CREATE INDEX IF NOT EXISTS idx_photos_status ON photos(status);
CREATE INDEX IF NOT EXISTS idx_photos_album ON photos(album_id);
CREATE INDEX IF NOT EXISTS idx_documents_public ON documents(is_public);
CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_logs(created_at DESC);

-- ==============================================================================
-- 23. ROW LEVEL SECURITY (RLS) POLICIES
-- ==============================================================================
ALTER TABLE admins ENABLE ROW LEVEL SECURITY;
ALTER TABLE villages ENABLE ROW LEVEL SECURITY;
ALTER TABLE designations ENABLE ROW LEVEL SECURITY;
ALTER TABLE community_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE projects ENABLE ROW LEVEL SECURITY;
ALTER TABLE youth_groups ENABLE ROW LEVEL SECURITY;
ALTER TABLE trades ENABLE ROW LEVEL SECURITY;
ALTER TABLE trainings ENABLE ROW LEVEL SECURITY;
ALTER TABLE employment_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE entrepreneurs ENABLE ROW LEVEL SECURITY;
ALTER TABLE education_achievements ENABLE ROW LEVEL SECURITY;
ALTER TABLE public_services ENABLE ROW LEVEL SECURITY;
ALTER TABLE government_engagements ENABLE ROW LEVEL SECURITY;
ALTER TABLE activities ENABLE ROW LEVEL SECURITY;
ALTER TABLE events ENABLE ROW LEVEL SECURITY;
ALTER TABLE albums ENABLE ROW LEVEL SECURITY;
ALTER TABLE photos ENABLE ROW LEVEL SECURITY;
ALTER TABLE documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE website_content ENABLE ROW LEVEL SECURITY;
ALTER TABLE impact_statistics ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE site_settings ENABLE ROW LEVEL SECURITY;

-- Public Read Policies (Only published/non-sensitive data visible to anonymous users)
CREATE POLICY "Public read active villages" ON villages FOR SELECT USING (status = 'active');
CREATE POLICY "Public read active designations" ON designations FOR SELECT USING (is_active = TRUE);
CREATE POLICY "Public read public members (non-archived)" ON community_members FOR SELECT USING (is_public = TRUE AND is_archived = FALSE);
CREATE POLICY "Public read published projects" ON projects FOR SELECT USING (is_published = TRUE);
CREATE POLICY "Public read active youth groups" ON youth_groups FOR SELECT USING (status = 'Active');
CREATE POLICY "Public read active trades" ON trades FOR SELECT USING (is_active = TRUE);
CREATE POLICY "Public read published trainings" ON trainings FOR SELECT USING (is_published = TRUE);
CREATE POLICY "Public read verified employment" ON employment_records FOR SELECT USING (verification_status = 'Verified');
CREATE POLICY "Public read verified entrepreneurs" ON entrepreneurs FOR SELECT USING (verification_status = 'Verified');
CREATE POLICY "Public read published education" ON education_achievements FOR SELECT USING (is_published = TRUE);
CREATE POLICY "Public read published activities" ON activities FOR SELECT USING (is_published = TRUE);
CREATE POLICY "Public read published events" ON events FOR SELECT USING (is_published = TRUE);
CREATE POLICY "Public read visible albums" ON albums FOR SELECT USING (is_visible = TRUE);
CREATE POLICY "Public read approved photos" ON photos FOR SELECT USING (is_published = TRUE AND status = 'approved');
CREATE POLICY "Public read public documents" ON documents FOR SELECT USING (is_public = TRUE);
CREATE POLICY "Public read website content" ON website_content FOR SELECT USING (TRUE);
CREATE POLICY "Public read impact statistics" ON impact_statistics FOR SELECT USING (is_active = TRUE);
CREATE POLICY "Public submit photo" ON photos FOR INSERT WITH CHECK (status = 'pending' AND is_published = FALSE);

-- Service Role Key (Serverless backend API) bypasses RLS automatically in Supabase.

-- ==============================================================================
-- 24. SEED VERIFIED RC SINDHRI DATA
-- ==============================================================================

-- 24.1 Seed 18 Verified Villages
INSERT INTO villages (name, uc, taluka, district, description) VALUES
    ('Village Haji Hamer Mangrio', 'Sindhri', 'Sindhri', 'Mirpur Khas', 'Headquarters of RC Sindhri; vocational center, library, and community hub.'),
    ('Village Lal Khan Shar', 'Sindhri', 'Sindhri', 'Mirpur Khas', 'Active youth mobilization and tree plantation outreach.'),
    ('Village Essa Khan Shar', 'Sindhri', 'Sindhri', 'Mirpur Khas', 'Community dialogues and health outreach sessions.'),
    ('Village Qadru Shar', 'Sindhri', 'Sindhri', 'Mirpur Khas', 'Vocational training and youth group representation.'),
    ('Village Satar Shar', 'Sindhri', 'Sindhri', 'Mirpur Khas', 'Awareness and educational advocacy coverage.'),
    ('Village Ali Khan Mangrio', 'Sindhri', 'Sindhri', 'Mirpur Khas', 'Community engagement and youth leadership activities.'),
    ('Village Jani Rasti', 'Sindhri', 'Sindhri', 'Mirpur Khas', 'Vocational skills and community advocacy meetings.'),
    ('Village Ghafor Mangrio', 'Sindhri', 'Sindhri', 'Mirpur Khas', 'Youth mobilization and health facilitation.'),
    ('Village Qasim Hotel', 'Sindhri', 'Sindhri', 'Mirpur Khas', 'Commercial focal point and youth skills participation.'),
    ('Village Khani Mangrio', 'Sindhri', 'Sindhri', 'Mirpur Khas', 'Site of GBPS Ahmed Abupoto education advocacy (50+ students).'),
    ('Village Dost Mohammed Abupoto', 'Sindhri', 'Sindhri', 'Mirpur Khas', 'Youth group and skills development outreach.'),
    ('Village Per Bux Mari', 'Sindhri', 'Sindhri', 'Mirpur Khas', 'Community outreach and vaccination awareness.'),
    ('Village Khameso Siyal', 'Sindhri', 'Sindhri', 'Mirpur Khas', 'Youth participation and climate action.'),
    ('Village Abdul Kareem Shar', 'Sindhri', 'Sindhri', 'Mirpur Khas', 'Community awareness and stage drama hosting.'),
    ('Village Ghuneso Bhel', 'Sindhri', 'Sindhri', 'Mirpur Khas', 'Marginalized community inclusion and vocational outreach.'),
    ('Village Jani Rasti Bheel', 'Sindhri', 'Sindhri', 'Mirpur Khas', 'Community facilitation and youth empowerment.'),
    ('Village Mohammed Hassan Mangrio', 'Sindhri', 'Sindhri', 'Mirpur Khas', 'Youth leadership and vocational skill training.'),
    ('Village Tando Gondal', 'Sindhri', 'Sindhri', 'Mirpur Khas', 'Agricultural community outreach and skills facilitation.'),
    ('Village Mohammed Ibrahim Mangrio', 'Sindhri', 'Sindhri', 'Mirpur Khas', 'Community dialogues and youth group activities.')
ON CONFLICT (name) DO NOTHING;

-- 24.2 Seed Designations
INSERT INTO designations (title, description, display_order) VALUES
    ('Focal Person', 'Lead representative coordinating project activities and reporting', 1),
    ('Coordinator', 'Program and operational workflow supervisor', 2),
    ('Community Mobilizer', 'Field staff organizing village meetings and community engagement', 3),
    ('Youth Leader', 'Representative elected by village youth groups', 4),
    ('Volunteer', 'Community volunteer supporting events, plantation, and outreach', 5),
    ('Trainer', 'Vocational and technical skills instructor', 6),
    ('Media Coordinator', 'Documentary, photography, and social communication focal person', 7),
    ('Field Officer', 'Field implementation and monitoring officer', 8),
    ('Committee Member', 'Village and advisory committee member', 9)
ON CONFLICT (title) DO NOTHING;

-- 24.3 Seed Projects
INSERT INTO projects (name, short_name, description, status, partner, funding_info, objectives, achievements, impact) VALUES
    ('Power to Youth (PTY)', 'PTY', 'Youth empowerment program establishing 8 youth groups, 240 vocational trainees, climate action, GBV awareness, and social advocacy across UC Sindhri.', 'Active', 'CSSP / NCA Pakistan', 'Verified Program Data', 'Strengthen young people and adolescent girls in leadership, vocational skills, and rights advocacy.', '240 vocational graduates across 7 trades; 8 youth groups (200 members); 10 stage drama performances; 18 villages reached.', '15+ youth earning through skills; 15+ youth started businesses; improved civic and health rights awareness.'),
    ('MANZIL', 'MANZIL', 'Youth leadership, livelihoods, enterprise, and digital skills development initiative with dedicated organizational structure and Mach Kachehri dialogues.', 'Active', 'Community Program', 'Verified Program Data', 'Foster youth leadership, digital literacy, and community enterprise.', 'Formed youth committees; conducted leadership sessions, cultural dialogues, and climate drives.', 'Enhanced youth participation in local governance and enterprise.'),
    ('RC Sindhri Community Development', 'RCCD', 'Core local community development platform providing vocational center facilities, public services facilitation, and emergency relief.', 'Ongoing', 'RC Sindhri Core', 'Community Supported', 'Provide sustainable rural community infrastructure, education advocacy, and government linkages.', 'Facilitated 400 NADRA MRV tokens (160 NIC cards issued); education advocacy at 3 institutions.', 'Established recognized rural youth center serving 18 surrounding villages.'),
    ('Vocational & Technical Training', 'VTP', 'Structured hands-on vocational courses in market-driven technical trades.', 'Ongoing', 'Technical Instructors', 'Skills Program', 'Equip rural youth with income-generating trades.', '240 certified trainees across Solar, Beautician, Dress Making, Masonry, Mobile Repairing, Embroidery, and E-Commerce.', 'Direct livelihood transformation for rural families.')
ON CONFLICT (short_name) DO NOTHING;

-- 24.4 Seed 7 Verified Trades (Total 240 Trainees)
INSERT INTO trades (name, description, duration, total_trainees_count, display_order) VALUES
    ('Solar System Installation & Repair', 'Photovoltaic solar system installation, battery bank maintenance, and inverter diagnosis.', '3 Months', 50, 1),
    ('Dress Making & Tailoring', 'Pattern cutting, modern garment stitching, and design for women empowerment.', '3 Months', 50, 2),
    ('Masonry & Construction', 'Building construction techniques, plastering, tile fixing, and structural masonry.', '3 Months', 50, 3),
    ('Beautician & Cosmetology', 'Professional parlour services, skincare, and bridal salon skills for female entrepreneurs.', '3 Months', 25, 4),
    ('Mobile Phone Repairing', 'Hardware chip-level troubleshooting, screen replacement, and software flashing.', '3 Months', 25, 5),
    ('Sindhi Embroidery & Handicrafts', 'Traditional Sindhi embroidery, applique work, rilli craft, and commercial finishing.', '3 Months', 25, 6),
    ('E-Commerce & Digital Literacy', 'Online freelancing, basic computer operation, product listing, and smartphone business tools.', '3 Months', 15, 7)
ON CONFLICT (name) DO NOTHING;

-- 24.5 Seed 8 Verified Youth Groups (200 Members, 2 Girls' Groups)
INSERT INTO youth_groups (name, group_type, member_count, focal_person, description) VALUES
    ('Haji Hamer Youth Group', 'Boys', 25, 'Imran Mangrio', 'Main youth committee representing Village Haji Hamer Mangrio.'),
    ('Haji Hamer Girls Youth Group', 'Girls', 25, 'Saima Mangrio', 'Dedicated young women leadership and skills group in Haji Hamer.'),
    ('Lal Khan Shar Youth Group', 'Boys', 25, 'Karamat Shar', 'Village Lal Khan Shar community action group.'),
    ('Essa Khan Shar Youth Group', 'Boys', 25, 'Zubair Shar', 'Village Essa Khan Shar youth mobilization group.'),
    ('Qadru Shar Youth Group', 'Boys', 25, 'Bilal Shar', 'Village Qadru Shar youth group focusing on vocational trades.'),
    ('Khani Mangrio Youth Group', 'Boys', 25, 'Asif Mangrio', 'Village Khani Mangrio group active in education advocacy.'),
    ('Ali Khan Mangrio Youth Group', 'Boys', 25, 'Waqar Mangrio', 'Village Ali Khan Mangrio youth representation group.'),
    ('Sindhri Central Girls Youth Group', 'Girls', 25, 'Fatima Shar', 'Adolescent girls rights and vocational group.')
ON CONFLICT DO NOTHING;

-- 24.6 Seed Verified Impact Statistics
INSERT INTO impact_statistics (stat_key, label, raw_value, display_value, icon, category, display_order) VALUES
    ('vocational_trainees', 'Vocational Trainees', 240, '240', 'fa-solid fa-graduation-cap', 'trainings', 1),
    ('youth_groups', 'Youth Groups', 8, '8', 'fa-solid fa-users', 'youth', 2),
    ('youth_members', 'Youth Members', 200, '200', 'fa-solid fa-user-group', 'youth', 3),
    ('awareness_sessions', 'Awareness Sessions', 50, '50+', 'fa-solid fa-bullhorn', 'activities', 4),
    ('stage_drama', 'Stage Drama Performances', 10, '10', 'fa-solid fa-theater-masks', 'activities', 5),
    ('nic_cards', 'NIC Cards Processed', 160, '160', 'fa-solid fa-id-card', 'services', 6),
    ('livelihood_cases', 'Youth Using Skills for Livelihood', 15, '15+', 'fa-solid fa-briefcase', 'livelihood', 7),
    ('entrepreneurs', 'Youth Entrepreneurs', 15, '15+', 'fa-solid fa-store', 'livelihood', 8),
    ('villages_covered', 'Villages Covered', 18, '18', 'fa-solid fa-map-location-dot', 'community', 9),
    ('climate_trained_youth', 'Youth Trained on Climate Action', 100, '100', 'fa-solid fa-seedling', 'climate', 10),
    ('health_reached', 'Health & Vaccination Mobilization', 560, '560+', 'fa-solid fa-heart-pulse', 'health', 11)
ON CONFLICT (stat_key) DO UPDATE SET
    raw_value = EXCLUDED.raw_value,
    display_value = EXCLUDED.display_value,
    updated_at = NOW();

-- 24.7 Seed Default Albums
INSERT INTO albums (slug, title, description, display_order) VALUES
    ('pty', 'PTY & Vocational Skills', 'Vocational skills training in solar repair, beautician trades, and digital literacy under Power to Youth.', 1),
    ('manzil', 'MANZIL & Leadership', 'Youth leadership, governance workshops, and community advocacy development.', 2),
    ('drama', 'Stage Drama Team', 'Social theatre performances on climate change, GBV awareness, education, and child rights.', 3),
    ('climate', 'Climate Action & Cleanliness', 'Community tree plantation drives, environmental clean-ups, and climate resilience awareness.', 4),
    ('gbv', 'GBV Awareness & Women Support', 'Community dialogues on women safety, early marriage prevention, and legal referral rights.', 5),
    ('nadra', 'NADRA MRV Facilitation', 'Mobile Registration Van facilitation enabling identity cards for women and rural citizens.', 6),
    ('health', 'Health & Vaccination Outreach', 'Community mobilization for COVID-19, Measles-Rubella (MR), and Polio immunization.', 7),
    ('community', 'Mach Kachehri & Community Events', 'Traditional open dialogues, social evenings, and village consultations.', 8),
    ('trainings', 'Workshops & Capacity Building', 'Specialized workshops and capacity building sessions for local community members.', 9)
ON CONFLICT (slug) DO NOTHING;

-- 24.8 Seed 28 Verified Committee Members (Management, PTY, MANZIL, Stage Drama)
INSERT INTO community_members (full_name, designation_title, department_area, committee_type, village_name, short_bio, display_order, status, is_public) VALUES
    ('Riaz Ali', 'President', 'RC Sindhri Management Committee', 'management', 'UC Sindhri', 'President of RC Sindhri Management Committee, providing strategic vision and leadership for all community development programs.', 1, 'Active', TRUE),
    ('Haji Hamer', 'Chief Patron & Founding Member', 'RC Sindhri Management Committee', 'management', 'Village Haji Hamer Mangrio', 'Respected community elder and founding patron who provided land and support to establish RC Sindhri vocational center.', 2, 'Active', TRUE),
    ('Sajjid Ali', 'General Secretary', 'RC Sindhri Management Committee', 'management', 'UC Sindhri', 'General Secretary responsible for administrative coordination, correspondence, and documentation of RC Sindhri activities.', 3, 'Active', TRUE),
    ('Tola Ram Bheel', 'Social Inclusion Representative', 'RC Sindhri Management Committee', 'management', 'UC Sindhri', 'Social inclusion representative ensuring the voices of all communities including minorities are heard in RC Sindhri programs.', 4, 'Active', TRUE),
    ('Irshad Ali', 'Finance & Accounts Officer', 'RC Sindhri Management Committee', 'management', 'UC Sindhri', 'Finance officer overseeing budgets, accounts, and financial transparency for all RC Sindhri programs and activities.', 5, 'Active', TRUE),
    ('Ali Mohamed Shar', 'Community Mobilization Officer', 'RC Sindhri Management Committee', 'management', 'Village Lal Khan Shar', 'Community mobilization officer driving outreach and awareness campaigns across all villages in UC Sindhri.', 6, 'Active', TRUE),
    ('Qurban Mari', 'Youth Programs Coordinator', 'RC Sindhri Management Committee', 'management', 'UC Sindhri', 'Youth programs coordinator facilitating training sessions, community events, and youth group activities for RC Sindhri.', 7, 'Active', TRUE),
    ('Imam Bux', 'President', 'PTY Management Committee', 'pty', 'UC Sindhri', 'President of PTY Management Committee leading Power to Youth program activities across 8 youth groups in UC Sindhri.', 1, 'Active', TRUE),
    ('Eijaz Ali Shar', 'Vice President', 'PTY Management Committee', 'pty', 'Village Lal Khan Shar', 'Vice President of PTY Committee supporting program planning, youth coordination, and vocational skills training supervision.', 2, 'Active', TRUE),
    ('Ramzan Siyal', 'General Secretary', 'PTY Management Committee', 'pty', 'UC Sindhri', 'General Secretary of PTY Committee managing documentation, meeting records, and official correspondence.', 3, 'Active', TRUE),
    ('Nazim Ali', 'Vocational Training Coordinator', 'PTY Management Committee', 'pty', 'UC Sindhri', 'Vocational Training Coordinator overseeing 7 trades training program for 240 youth trainees under PTY.', 4, 'Active', TRUE),
    ('Noor Mohammed', 'Community Liaison Officer', 'PTY Management Committee', 'pty', 'UC Sindhri', 'Community Liaison Officer bridging PTY program activities with local villages, families, and community stakeholders.', 5, 'Active', TRUE),
    ('Raziq Dino', 'Finance & Resources Officer', 'PTY Management Committee', 'pty', 'UC Sindhri', 'Finance and Resources Officer managing PTY program budgets, resource allocation, and financial reporting.', 6, 'Active', TRUE),
    ('Mola Bux Shar', 'President', 'MANZIL Management Committee', 'manzil', 'Village Lal Khan Shar', 'President of MANZIL Committee providing strategic leadership for youth livelihoods, entrepreneurship, and civic engagement.', 1, 'Active', TRUE),
    ('Ali Nawaz', 'Vice President', 'MANZIL Management Committee', 'manzil', 'UC Sindhri', 'Vice President supporting MANZIL program operations, leadership training, and youth group coordination.', 2, 'Active', TRUE),
    ('Yasir Ali', 'General Secretary', 'MANZIL Management Committee', 'manzil', 'UC Sindhri', 'General Secretary managing MANZIL committee correspondence, meeting minutes, and program documentation.', 3, 'Active', TRUE),
    ('Nisar Ali', 'Enterprise & Livelihoods Coordinator', 'MANZIL Management Committee', 'manzil', 'UC Sindhri', 'Enterprise coordinator supporting youth in starting businesses and improving economic self-sufficiency.', 4, 'Active', TRUE),
    ('Asif Ali', 'Climate & Environment Coordinator', 'MANZIL Management Committee', 'manzil', 'UC Sindhri', 'Climate coordinator leading tree plantation drives and climate change awareness campaigns across UC Sindhri.', 5, 'Active', TRUE),
    ('Jan Mohammed Shar', 'Cultural & Drama Coordinator', 'MANZIL Management Committee', 'manzil', 'Village Lal Khan Shar', 'Cultural and drama coordinator organizing stage drama performances and cultural programs for community awareness.', 6, 'Active', TRUE),
    ('Imam Bux Mangrio', 'Lead Coordinator & Director', 'Stage Drama Committee', 'drama', 'Village Haji Hamer Mangrio', 'Lead Coordinator & Director overseeing community theater performances, script development, and social message delivery across UC Sindhri.', 1, 'Active', TRUE),
    ('Eijaz Ali Mangrio', 'Associate Director & Stage Manager', 'Stage Drama Committee', 'drama', 'Village Haji Hamer Mangrio', 'Associate Director and Stage Manager managing backstage coordination, actor rehearsals, and production logistics for village performances.', 2, 'Active', TRUE),
    ('Nazim Ali Mangrio', 'Senior Actor & Creative Lead', 'Stage Drama Committee', 'drama', 'UC Sindhri', 'Senior Actor and Creative Lead portraying key educational characters addressing girls'' education, youth rights, and community harmony.', 3, 'Active', TRUE),
    ('Nisar Ali Mangrio', 'Production & Logistics Coordinator', 'Stage Drama Committee', 'drama', 'UC Sindhri', 'Production and Logistics Coordinator organizing performance venues, sound equipment, stage setup, and audience arrangements across 18 villages.', 4, 'Active', TRUE),
    ('Haji Hamer Mangrio', 'Cultural Patron & Advisor', 'Stage Drama Committee', 'drama', 'Village Haji Hamer Mangrio', 'Founding patron and cultural elder providing guidance and community endorsement for stage dramas promoting social awareness.', 5, 'Active', TRUE),
    ('Mola Bux Shar', 'Social Awareness Dialogue Lead', 'Stage Drama Committee', 'drama', 'Village Lal Khan Shar', 'Dialogue Lead facilitating post-performance discussions with village elders and audiences to reinforce key social and civic messages.', 6, 'Active', TRUE),
    ('Sorath', 'Lead Female Performer', 'Stage Drama Committee', 'drama', 'RC Girhor Sharif, UC Girhor Sharif', 'Lead Female Performer championing women''s empowerment, girl-child education, and gender awareness through powerful theatrical roles.', 7, 'Active', TRUE),
    ('Saba', 'Female Youth Performer & Mobilizer', 'Stage Drama Committee', 'drama', 'RC Girhor Sharif, UC Girhor Sharif', 'Female youth artist actively performing in health awareness, hygiene, and social reform stage dramas across UC Sindhri.', 8, 'Active', TRUE),
    ('Pirbhat', 'Cultural Performer & Youth Artist', 'Stage Drama Committee', 'drama', 'RC Girhor Sharif, UC Girhor Sharif', 'Dedicated cultural performer contributing to indigenous Sindhi drama traditions and inspiring rural youth participation in arts.', 9, 'Active', TRUE);

-- ==============================================================================
-- 25. EMPLOYMENT & RECRUITMENT PLATFORM (RC SINDHRI - ROZGAR CENTER)
-- Tagline: "Connecting Talent with Opportunities"
-- ==============================================================================

-- 25.1 Employers Table
CREATE TABLE IF NOT EXISTS employers (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    company_name TEXT NOT NULL,
    industry TEXT NOT NULL,
    contact_person TEXT,
    email TEXT,
    phone TEXT,
    location TEXT DEFAULT 'Sindhri',
    address TEXT,
    website TEXT,
    logo_url TEXT,
    verification_status TEXT NOT NULL DEFAULT 'Verified' CHECK (verification_status IN ('Verified', 'Pending', 'Rejected')),
    status TEXT NOT NULL DEFAULT 'Active' CHECK (status IN ('Active', 'Inactive')),
    description TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 25.2 Candidates Table
CREATE TABLE IF NOT EXISTS candidates (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    full_name TEXT NOT NULL,
    email TEXT,
    phone TEXT,
    gender TEXT CHECK (gender IN ('Male', 'Female', 'Other')),
    village_id UUID REFERENCES villages(id) ON DELETE SET NULL,
    village_name TEXT DEFAULT 'Village Haji Hamer Mangrio',
    location TEXT DEFAULT 'Sindhri',
    education TEXT,
    experience_years TEXT,
    skills TEXT,
    trade_id UUID REFERENCES trades(id) ON DELETE SET NULL,
    trade_name TEXT,
    resume_url TEXT,
    bio TEXT,
    account_status TEXT NOT NULL DEFAULT 'Active' CHECK (account_status IN ('Active', 'Inactive', 'Blocked')),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 25.3 Jobs Table
CREATE TABLE IF NOT EXISTS jobs (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    title TEXT NOT NULL,
    employer_id UUID REFERENCES employers(id) ON DELETE CASCADE,
    employer_name TEXT NOT NULL,
    category TEXT NOT NULL CHECK (category IN ('IT & Software', 'Education', 'Healthcare', 'Construction', 'Sales & Marketing', 'Technical & Vocational', 'Others')),
    employment_type TEXT NOT NULL DEFAULT 'Full-time' CHECK (employment_type IN ('Full-time', 'Part-time', 'Contract', 'Apprenticeship', 'Internship')),
    location TEXT DEFAULT 'Sindhri',
    salary_range TEXT,
    experience_required TEXT,
    education_required TEXT,
    skills_required TEXT,
    description TEXT NOT NULL,
    requirements TEXT,
    responsibilities TEXT,
    deadline DATE,
    status TEXT NOT NULL DEFAULT 'Active' CHECK (status IN ('Active', 'Pending', 'Expired', 'Draft')),
    is_published BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 25.4 Applications Table
CREATE TABLE IF NOT EXISTS applications (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    job_id UUID REFERENCES jobs(id) ON DELETE CASCADE,
    job_title TEXT NOT NULL,
    candidate_id UUID REFERENCES candidates(id) ON DELETE CASCADE,
    candidate_name TEXT NOT NULL,
    candidate_email TEXT,
    candidate_phone TEXT,
    employer_id UUID REFERENCES employers(id) ON DELETE CASCADE,
    employer_name TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'Pending' CHECK (status IN ('Pending', 'Under Review', 'Shortlisted', 'Interview', 'Selected', 'Rejected', 'Withdrawn')),
    cover_letter TEXT,
    notes TEXT,
    interview_date TIMESTAMPTZ,
    applied_on DATE DEFAULT CURRENT_DATE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 25.5 App Users Table
CREATE TABLE IF NOT EXISTS app_users (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    email TEXT UNIQUE NOT NULL,
    full_name TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'Admin' CHECK (role IN ('Super Admin', 'Admin', 'Staff', 'Employer', 'Job Seeker')),
    status TEXT NOT NULL DEFAULT 'Active' CHECK (status IN ('Active', 'Inactive', 'Suspended')),
    phone TEXT,
    avatar_url TEXT,
    last_login TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 25.6 Notifications Table
CREATE TABLE IF NOT EXISTS notifications (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    title TEXT NOT NULL,
    message TEXT NOT NULL,
    type TEXT NOT NULL DEFAULT 'system' CHECK (type IN ('application', 'job', 'employer', 'candidate', 'system')),
    entity_id TEXT,
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 25.7 Activity Logs Table
CREATE TABLE IF NOT EXISTS activity_logs (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    type TEXT NOT NULL,
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    user_email TEXT DEFAULT 'rcsindhri@gmail.com',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_jobs_status ON jobs(status);
CREATE INDEX IF NOT EXISTS idx_jobs_category ON jobs(category);
CREATE INDEX IF NOT EXISTS idx_applications_job ON applications(job_id);
CREATE INDEX IF NOT EXISTS idx_applications_candidate ON applications(candidate_id);
CREATE INDEX IF NOT EXISTS idx_applications_status ON applications(status);
CREATE INDEX IF NOT EXISTS idx_candidates_status ON candidates(account_status);
CREATE INDEX IF NOT EXISTS idx_employers_status ON employers(status);

-- Enable RLS
ALTER TABLE employers ENABLE ROW LEVEL SECURITY;
ALTER TABLE candidates ENABLE ROW LEVEL SECURITY;
ALTER TABLE jobs ENABLE ROW LEVEL SECURITY;
ALTER TABLE applications ENABLE ROW LEVEL SECURITY;
ALTER TABLE app_users ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE activity_logs ENABLE ROW LEVEL SECURITY;

-- Public can view active jobs
CREATE POLICY "Public can view active jobs" ON jobs
    FOR SELECT USING (is_published = TRUE AND status = 'Active');

-- Public can view verified employers
CREATE POLICY "Public can view verified employers" ON employers
    FOR SELECT USING (status = 'Active' AND verification_status = 'Verified');

-- Public candidates can submit applications
CREATE POLICY "Public can submit applications" ON applications
    FOR INSERT WITH CHECK (status = 'Pending');

